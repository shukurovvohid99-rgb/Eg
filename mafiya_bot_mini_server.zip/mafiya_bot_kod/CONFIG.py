import os

# Токен бота берётся ТОЛЬКО из переменной окружения.
# Хардкодить его в файл нельзя: Render деплоит из GitHub-репозитория,
# и вписанный в код токен утечёт всем, кто откроет репозиторий.
TOKEN = os.getenv("BOT_TOKEN")

if not TOKEN:
    raise RuntimeError(
        "Не задан BOT_TOKEN. Локально: BOT_TOKEN=... python run.py; "
        "на Render: вкладка Environment -> Add Environment Variable -> BOT_TOKEN"
    )

# Юзернейм бота — используется в кнопках "Перейти в бот" / "Добавить в чат"
BOT_USERNAME = os.getenv("BOT_USERNAME", "Mafghgfia_bot")
