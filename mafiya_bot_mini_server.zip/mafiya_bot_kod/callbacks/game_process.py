import os
import random
import sqlite3
import logging
from datetime import datetime, timedelta
from typing import List

from aiogram import Bot, F, Router
from aiogram.filters import BaseFilter
from aiogram.types import CallbackQuery, Message
from aiogram.filters.callback_data import CallbackData
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.date import DateTrigger

from handlers import registration, economy
from utils import esc, safe_send, safe_set_permissions
import keyboards as kb


is_night = False
night_actions: list["NightCallback"] = []
voted_people: list[int] = []
accused_people: dict[int, int] = {}
vote_choices: dict[int, int] = {}
silenced_people: set[int] = set()
protected_people: set[int] = set()
night_action_users: set[int] = set()
doctor_self_heal_used: set[int] = set()
pending_sorcerer: set[int] = set()
pending_vote_target: int | None = None
commissioner_revealed = False
player_health: dict[int, int] = {}
hero_guarded: set[int] = set()
day = 1
night_job = None
vote_job = None
apscheduler = AsyncIOScheduler()


class NightFilter(BaseFilter):
    async def __call__(self, callback: CallbackQuery) -> bool:
        return is_night


class DayFilter(BaseFilter):
    async def __call__(self, callback: CallbackQuery) -> bool:
        return not is_night and registration.game_start


night_router = Router(name="night_router")
night_router.callback_query.filter(NightFilter())
day_router = Router(name="day_router")
day_router.callback_query.filter(DayFilter())


class NightCallback(CallbackData, prefix="night"):
    user: int
    target: int
    action: str
    day: int


class VoteCallback(CallbackData, prefix="vote"):
    target: int
    day: int


class Player:
    action = "sleep"
    role_name = "Tinch aholi"
    team = "town"

    def __init__(self, user):
        self.id = user.id
        self.full_name = user.full_name
        self.safe_name = esc(user.full_name)

    def __str__(self):
        return self.safe_name

    async def sleep(self, bot: Bot):
        await safe_send(bot, self.id, "🔵 Sizning tungi harakatingiz yo‘q. Tongni kuting.", reply_markup=night_kb("sleep", self))


class Mafia(Player):
    action = "vote_kill"
    role_name = "Mafia"
    team = "mafia"

    async def vote_kill(self, bot: Bot):
        await safe_send(bot, self.id, "🔫 Donga qurbonni taklif qiling:", reply_markup=night_kb(registration.live_players, self, exclude_self=True))


class Don(Player):
    action = "kill"
    role_name = "Don"
    team = "mafia"

    async def kill(self, bot: Bot):
        await safe_send(bot, self.id, "👑 Bu kecha kimni o‘ldirasiz?", reply_markup=night_kb(registration.live_players, self, exclude_self=True))


class Doctor(Player):
    action = "heal"
    role_name = "Doctor"
    team = "town"

    async def heal(self, bot: Bot):
        await safe_send(bot, self.id, "👨🏻‍⚕ Kimni davolaysiz? O‘zingizni faqat bir marta davolashingiz mumkin.", reply_markup=night_kb(registration.live_players, self))


class Commissioner(Player):
    action = "commissioner_check"
    role_name = "Komissar katani"
    team = "town"

    async def commissioner_action(self, bot: Bot):
        builder = InlineKeyboardBuilder()
        for player in registration.live_players:
            if player.id == self.id:
                continue
            builder.button(text=f"🔎 Tekshirish: {player.full_name[:25]}", callback_data=NightCallback(user=self.id, target=player.id, action="commissioner_check", day=day).pack())
            if day > 1:
                builder.button(text=f"🔫 Otish: {player.full_name[:25]}", callback_data=NightCallback(user=self.id, target=player.id, action="commissioner_shoot", day=day).pack())
        builder.adjust(1)
        if day == 1:
            text = "🕵🏻‍♂ Birinchi tunda faqat tekshirishingiz mumkin. Tekshirmasdan otish taqiqlanadi."
        else:
            text = "🕵🏻‍♂ Kimni tekshirasiz yoki otasiz?"
        await safe_send(bot, self.id, text, reply_markup=builder.as_markup())


class Sergeant(Player):
    action = "sleep"
    role_name = "Serjant"
    team = "town"


class Kezuvchi(Player):
    action = "sleep_drug"
    role_name = "Kezuvchi"
    team = "town"

    async def sleep_drug(self, bot: Bot):
        await safe_send(bot, self.id, "💃 Kimni uxlatib, keyingi kunduz ovozdan mahrum qilasiz? Komissarni uxlatish mumkin emas.", reply_markup=night_kb(registration.live_players, self, exclude_self=True))


class DoctorWitness(Player):
    pass


class Daydi(Player):
    action = "daydi_visit"
    role_name = "Daydi"
    team = "town"

    async def visit(self, bot: Bot):
        await safe_send(bot, self.id, "🧙‍♂️ Tunda kimning oldiga borib guvoh bo‘lasiz?", reply_markup=night_kb(registration.live_players, self, exclude_self=True))


class Sorcerer(Player):
    action = "sleep"
    role_name = "Afsungar"
    team = "town"


class Advocate(Player):
    action = "advocate_protect"
    role_name = "Advokat"
    team = "mafia"

    async def protect(self, bot: Bot):
        await safe_send(bot, self.id, "👨‍💼 Kimni himoya qilasiz? Himoyalangan Mafia Komissarga Tinch aholi bo‘lib ko‘rinadi.", reply_markup=night_kb(registration.live_players, self))


class Killer(Player):
    action = "killer_kill"
    role_name = "Qotil"
    team = "killer"

    async def kill(self, bot: Bot):
        await safe_send(bot, self.id, "🔪 Bu kecha kimni o‘ldirasiz? Siz faqat o‘zingiz tirik qolsangiz g‘olib bo‘lasiz.", reply_markup=night_kb(registration.live_players, self, exclude_self=True))


class Wolf(Player):
    action = "sleep"
    role_name = "Bo‘ri"
    team = "wolf"


# Kechikkan callbacklar va yordamchi obyektlar uchun oddiy, Telegram User ga o‘xshash obyekt.
def _user_proxy(player):
    return type("User", (), {"id": player.id, "full_name": player.full_name})()


def _live_player(user_id: int):
    return next((player for player in registration.live_players if player.id == user_id), None)


def _inventory_connection():
    db_path = os.getenv("ECONOMY_DB", "economy.sqlite3")
    connection = sqlite3.connect(db_path)
    connection.row_factory = sqlite3.Row
    connection.execute("CREATE TABLE IF NOT EXISTS inventory (user_id INTEGER NOT NULL, item_id TEXT NOT NULL, quantity INTEGER NOT NULL DEFAULT 0, PRIMARY KEY (user_id, item_id))")
    return connection


def _has_item(user_id: int, item_id: str) -> bool:
    with _inventory_connection() as connection:
        row = connection.execute("SELECT quantity FROM inventory WHERE user_id=? AND item_id=?", (user_id, item_id)).fetchone()
        return bool(row and row["quantity"] > 0)


def _consume_item(user_id: int, item_id: str) -> bool:
    with _inventory_connection() as connection:
        changed = connection.execute("UPDATE inventory SET quantity=quantity-1 WHERE user_id=? AND item_id=? AND quantity>0", (user_id, item_id))
        return changed.rowcount == 1


def _mafia(player) -> bool:
    return isinstance(player, (Mafia, Don, Advocate))


def _replace_player(old_player, new_class):
    new_player = new_class(_user_proxy(old_player))
    index = registration.live_players.index(old_player)
    registration.live_players[index] = new_player
    return new_player


def reset_game_state() -> None:
    global day, commissioner_revealed, pending_vote_target
    day = 1
    commissioner_revealed = False
    pending_vote_target = None
    doctor_self_heal_used.clear()
    pending_sorcerer.clear()
    player_health.clear()
    hero_guarded.clear()
    _reset_round_state()


def _cancel_job(job):
    if job is not None:
        try:
            apscheduler.remove_job(job.id)
        except Exception:
            pass


def _reset_round_state() -> None:
    night_actions.clear()
    voted_people.clear()
    accused_people.clear()
    vote_choices.clear()
    silenced_people.clear()
    protected_people.clear()
    night_action_users.clear()
    global pending_vote_target
    pending_vote_target = None


def night_kb(players: list | str, executor: Player, exclude_self: bool = False) -> InlineKeyboardMarkup:
    if isinstance(players, str):
        return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="Kutish 😴", callback_data=NightCallback(user=executor.id, target=0, action="sleep", day=day).pack())]])
    builder = InlineKeyboardBuilder()
    for player in players:
        if exclude_self and player.id == executor.id:
            continue
        builder.button(text=player.full_name[:40], callback_data=NightCallback(user=executor.id, target=player.id, action=executor.action, day=day).pack())
    builder.adjust(1)
    return builder.as_markup()


def vote_kb(players: list) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for player in players:
        builder.button(text=f"🗳 {player.full_name[:35]}", callback_data=VoteCallback(target=player.id, day=day).pack(), style="primary")
    builder.button(text="⏭ Ovoz bermaslik", callback_data=VoteCallback(target=0, day=day).pack(), style="danger")
    builder.adjust(1)
    return builder.as_markup()


def check_game_end(live_players: list):
    if registration.vs_mode:
        red_alive = any(getattr(player, "vs_team", None) == "red" for player in live_players)
        blue_alive = any(getattr(player, "vs_team", None) == "blue" for player in live_players)
        if red_alive and not blue_alive:
            return "red win"
        if blue_alive and not red_alive:
            return "blue win"
        return None
    if len(live_players) == 1 and isinstance(live_players[0], Killer):
        return "killer win"
    mafia_count = sum(1 for player in live_players if _mafia(player))
    killer_alive = any(isinstance(player, Killer) for player in live_players)
    # Mafia faqat Tinch aholi jamoasi (oddiy fuqaro va barcha yaxshi rollar)
    # soni Mafia soniga tenglashganda yoki undan kamayganda g‘alaba qiladi.
    # Mustaqil rollar (Qotil/Bo‘ri va boshqalar) bu hisobga kiritilmaydi.
    town_count = sum(1 for player in live_players if getattr(player, "team", None) == "town")
    if mafia_count == 0 and not killer_alive:
        return "peaceful win"
    if mafia_count > 0 and mafia_count >= town_count:
        return "mafia win"
    if not any(isinstance(player, Don) for player in live_players) and any(isinstance(player, Mafia) for player in live_players):
        old_mafia = next(player for player in live_players if isinstance(player, Mafia))
        promoted = _replace_player(old_mafia, Don)
        return "new don"
    return None


async def _announce_end_or_continue(bot: Bot) -> bool:
    result = check_game_end(registration.live_players)
    if result in {"mafia win", "peaceful win", "killer win", "red win", "blue win"}:
        messages = {
            "mafia win": "🔫 <b>Mafiya g‘alaba qozondi!</b>",
            "peaceful win": "👥 <b>Tinch aholi g‘alaba qozondi!</b>",
            "killer win": "🔪 <b>Qotil yagona tirik o‘yinchi bo‘lib g‘alaba qozondi!</b>",
            "red win": "🔴 <b>Qizil jamoa g‘alaba qozondi!</b>",
            "blue win": "🔵 <b>Ko‘k jamoa g‘alaba qozondi!</b>",
        }
        team = {"mafia win": "mafia", "peaceful win": "town", "killer win": "killer", "red win": "red", "blue win": "blue"}[result]
        participant_ids = set(registration.game_participant_ids)
        participant_ids.update(user.id for user in registration.active_users)
        participant_ids.update(player.id for player in registration.live_players)
        winner_ids = {
            player.id for player in registration.live_players
            if (getattr(player, "vs_team", None) if registration.vs_mode else getattr(player, "team", None)) == team
        }
        award_key = f"{registration.game_chat_id}:{registration.registration_message_id}"
        rewards = economy.award_game_rewards(participant_ids, winner_ids, day, award_key=award_key)
        winners = sum(1 for _, _, _, won in rewards if won)
        losers = sum(1 for _, _, _, won in rewards if not won)
        await bot.send_message(registration.game_chat_id, messages[result])
        await bot.send_message(
            registration.game_chat_id,
            f"🎁 <b>O‘yin mukofotlari</b>\nG‘oliblar: {winners} ta — 20 💵 va qatnashuvga qarab ball.\n"
            f"Qolganlar: {losers} ta — 1–5 💵 va qatnashuvga qarab −1…−5 ball.\n"
            "🏆 Batafsil reyting: /top, /top 1, /top 7 yoki /top 30",
        )
        await finish_game()
        return True
    if result == "new don":
        new_don = next(player for player in registration.live_players if isinstance(player, Don))
        await safe_send(bot, new_don.id, "👑 Endi siz yangi <b>Don</b> bo‘ldingiz. Mafiya qurbonini siz tanlaysiz.")
        await bot.send_message(registration.game_chat_id, "👑 Don halok bo‘ldi. Tirik Mafia a’zolaridan biri yangi Don bo‘ldi.")
    return False


async def finish_game() -> None:
    global is_night, night_job, vote_job
    _cancel_job(night_job)
    _cancel_job(vote_job)
    night_job = None
    vote_job = None
    is_night = False
    registration.game_start = False
    registration.registration_start = False
    registration.play_writed = False
    registration.active_users.clear()
    registration.live_players.clear()
    reset_game_state()
    registration._clear_game_state()


async def _sorcerer_day_effect(bot: Bot, sorcerer: Player):
    if not registration.game_start:
        return
    pending_sorcerer.add(sorcerer.id)
    builder = InlineKeyboardBuilder()
    for player in registration.live_players:
        builder.button(text=f"🔥 O‘zingiz bilan olib ketish: {player.full_name[:28]}", callback_data=NightCallback(user=sorcerer.id, target=player.id, action="sorcerer_kill", day=day).pack())
    builder.adjust(1)
    await safe_send(bot, sorcerer.id, "🧞‍♂️ Kunduzgi ovozda chiqarildingiz. O‘zingiz bilan bitta o‘yinchini olib keting.", reply_markup=builder.as_markup())


async def night_actions_result(actions: List[NightCallback], bot: Bot) -> None:
    global is_night, day, night_job
    if not registration.game_start or not is_night:
        return
    actions = list(actions)
    attack_actions = [action for action in actions if action.action in {"kill", "killer_kill", "commissioner_shoot"} and _live_player(action.target)]
    effective_attacks = []
    for action in attack_actions:
        # Don yoki Komissar miltiqga ega bo‘lsa, nishondagi oddiy himoyani chetlab o‘tadi.
        if action.action in {"kill", "commissioner_shoot"} and _has_item(action.user, "miltiq"):
            _consume_item(action.user, "miltiq")
            await safe_send(bot, action.user, "🔫 Miltiq ishlatildi: himoya chetlab o‘tildi.")
            effective_attacks.append(action)
        elif action.action in {"kill", "commissioner_shoot"} and _consume_item(action.target, "himoya"):
            await safe_send(bot, action.target, "🛡 Himoya ishladi: Don yoki Komissar hujumidan omon qoldingiz.")
        else:
            effective_attacks.append(action)
    attack_actions = effective_attacks
    attackers_by_target = {action.target: action.user for action in attack_actions}
    targets_to_kill = set(attackers_by_target)
    advocate_targets = {action.target for action in actions if action.action == "advocate_protect"}
    protected_people.clear()
    protected_people.update(advocate_targets)
    silenced_people.clear()
    for action in actions:
        if action.action != "sleep_drug":
            continue
        if _consume_item(action.target, "dori_himoya"):
            await safe_send(bot, action.target, "💊 Doridan himoya ishladi: Kezuvchi sizni uxlatolmadi.")
        else:
            silenced_people.add(action.target)
    heal_targets = {action.target for action in actions if action.action == "heal"}
    death_ids = set(targets_to_kill)
    # Advokat himoyasi faqat Komissar tekshiruvini yashiradi; u Mafia hujumini bekor qilmaydi.

    # Doctor davosi: hujum nishoni tirik qoladi. O‘zini davolash faqat bir marta.
    death_ids.difference_update(heal_targets)

    # Bo‘ri uni kim o‘ldirganiga qarab qayta tug‘iladi.
    for target_id in list(death_ids):
        target = _live_player(target_id)
        attacker = _live_player(attackers_by_target.get(target_id, 0))
        if isinstance(target, Wolf) and isinstance(attacker, (Mafia, Don)):
            _replace_player(target, Mafia)
            death_ids.remove(target_id)
            await safe_send(bot, target.id, "🐺 Bo‘ri sifatida Mafia tomonidan o‘ldirildingiz, ammo keyingi kecha Mafia bo‘lib tirildingiz.")
        elif isinstance(target, Wolf) and isinstance(attacker, Commissioner):
            _replace_player(target, Sergeant)
            death_ids.remove(target_id)
            await safe_send(bot, target.id, "🐺 Komissar sizni otdi. Siz yangi 👮🏻‍♂ Serjant bo‘lib tirildingiz.")

    # Afsungar tunda o‘ldirilsa, uni o‘ldirgan o‘yinchini o‘zi bilan olib ketadi.
    for target_id in list(death_ids):
        target = _live_player(target_id)
        attacker_id = attackers_by_target.get(target_id)
        if isinstance(target, Sorcerer) and attacker_id and _live_player(attacker_id):
            death_ids.add(attacker_id)
            await bot.send_message(registration.game_chat_id, "🧞‍♂️ Afsungar o‘ldirildi va uni o‘ldirgan o‘yinchini ham jahannamga olib ketdi.")

    deaths = [player for player in list(registration.live_players) if player.id in death_ids]
    commissioner_died = any(isinstance(player, Commissioner) for player in deaths)
    for player in deaths:
        registration.live_players.remove(player)

    if commissioner_died:
        sergeant = next((player for player in registration.live_players if isinstance(player, Sergeant)), None)
        if sergeant:
            new_commissioner = _replace_player(sergeant, Commissioner)
            await safe_send(bot, new_commissioner.id, "🕵🏻‍♂ Komissar vafot etdi. Siz uning o‘rnini egalladingiz va endi tekshirish huquqiga egasiz.")
            await bot.send_message(registration.game_chat_id, "👮🏻‍♂ Serjant Komissar katani o‘rnini egalladi.")

    for action in actions:
        if action.action == "daydi_visit":
            if action.target in death_ids:
                killer_id = attackers_by_target.get(action.target)
                killer = _live_player(killer_id) if killer_id else None
                witness_text = f"🧙‍♂️ Siz guvoh bo‘ldingiz: {killer} hujum qilganini ko‘rdingiz." if killer else "🧙‍♂️ Siz borgan o‘yinchi tunda halok bo‘ldi, lekin qotil yashirin qoldi."
                await safe_send(bot, action.user, witness_text)
            else:
                await safe_send(bot, action.user, "🧙‍♂️ Bu kecha siz borgan joyda qotillik bo‘lmadi.")

    await safe_set_permissions(bot, registration.game_chat_id, True)
    await bot.send_message(registration.game_chat_id, "⚪️ <b>Shahar uyg‘ondi.</b>")
    if deaths:
        names = " va ".join(str(player) for player in deaths)
        await bot.send_message(registration.game_chat_id, f"🔴 Bu kecha {names} halok bo‘ldi.")
    else:
        await bot.send_message(registration.game_chat_id, "🔵 Bu kecha hech kim halok bo‘lmadi.")
    day += 1
    is_night = False
    night_actions.clear()
    night_action_users.clear()
    night_job = None
    if await _announce_end_or_continue(bot):
        return
    registration._save_game_state("game")
    await start_day(bot)


async def start_day(bot: Bot) -> None:
    global vote_job
    voted_people.clear()
    accused_people.clear()
    discussion_seconds = 30
    hero_guarded.clear()
    await bot.send_message(registration.game_chat_id, f"⚫️ <b>Kunduzgi muhokama va ovoz berish boshlandi.</b>\nTiriklar shubhali o‘yinchini tanlang. Vaqt: <b>{discussion_seconds} soniya</b>.", reply_markup=vote_kb(registration.live_players))
    _cancel_job(vote_job)
    vote_job = apscheduler.add_job(vote_process, DateTrigger(run_date=datetime.now() + timedelta(seconds=discussion_seconds)), args=[bot])


def vote_confirmation_keyboard(target_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="👍", callback_data=f"vote_confirm:yes:{target_id}", style="success"),
            InlineKeyboardButton(text="👎", callback_data=f"vote_confirm:no:{target_id}", style="danger"),
        ]
    ])


async def eliminate_voted_player(bot: Bot, target_id: int) -> None:
    eliminated = _live_player(target_id)
    if not eliminated:
        return
    if _consume_item(eliminated.id, "osish_himoya"):
        await bot.send_message(registration.game_chat_id, f"🛡 <b>{eliminated}</b> osishdan himoya buyumidan foydalandi va o‘yinda qoldi.")
    else:
        registration.live_players.remove(eliminated)
        role_label = getattr(eliminated, "role_name", eliminated.__class__.__name__)
        await bot.send_message(registration.game_chat_id, f"🚪 <b>{eliminated}</b> shahardan chiqarildi.\n🎭 Uning roli: <b>{esc(role_label)}</b>")
        if isinstance(eliminated, Commissioner):
            sergeant = next((player for player in registration.live_players if isinstance(player, Sergeant)), None)
            if sergeant:
                new_commissioner = _replace_player(sergeant, Commissioner)
                await safe_send(bot, new_commissioner.id, "🕵🏻‍♂ Komissar ovoz bilan chiqarildi. Siz Serjant sifatida uning o‘rnini egalladingiz.")
                await bot.send_message(registration.game_chat_id, "👮🏻‍♂ Serjant yangi Komissar bo‘ldi.")
        if isinstance(eliminated, Sorcerer):
            await _sorcerer_day_effect(bot, eliminated)


async def continue_after_vote(bot: Bot) -> None:
    await _announce_end_or_continue(bot)
    if not registration.game_start:
        return
    registration._save_game_state("game")
    await bot.send_message(registration.game_chat_id, "🔵 <b>Shahar uyquga ketmoqda.</b> Tungi harakatlar shaxsiy chatda bajariladi.", reply_markup=kb.go_to_bot_keyboard)
    await send_hero_actions(bot)
    await night_phase(registration.live_players, bot)


async def vote_process(bot: Bot) -> None:
    global is_night, vote_job, pending_vote_target
    if not registration.game_start or is_night:
        return
    vote_job = None
    if accused_people:
        highest = max(accused_people.values())
        candidates = [target for target, count in accused_people.items() if count == highest]
        if len(candidates) == 1 and candidates[0] != 0:
            pending_vote_target = candidates[0]
            target = _live_player(pending_vote_target)
            if target:
                total_votes = sum(accused_people.values())
                disagree_votes = max(0, total_votes - highest)
                await bot.send_message(
                    registration.game_chat_id,
                    f"⚖️ Eng ko‘p ovoz olgan o‘yinchi: <b>{esc(getattr(target, 'username', None) and '@' + target.username or target.full_name)}</b>\n\n"
                    f"Rostdan ham uni osamizmi?\n"
                    f"👍 <b>{highest}</b>\n"
                    f"👎 <b>{disagree_votes}</b>",
                    reply_markup=vote_confirmation_keyboard(target.id),
                )
                return
        else:
            await bot.send_message(registration.game_chat_id, "⚖️ Ovozlar teng bo‘ldi yoki ko‘pchilik o‘tkazib yubordi. Hech kim chiqarilmadi.")
    else:
        await bot.send_message(registration.game_chat_id, "⏭ Ovoz berilmadi. Hech kim chiqarilmadi.")
    is_night = True
    await continue_after_vote(bot)


@day_router.callback_query(F.data.startswith("vote_confirm:"))
async def vote_confirmation_handler(callback: CallbackQuery, bot: Bot):
    global is_night, pending_vote_target
    parts = callback.data.split(":")
    if len(parts) != 3 or pending_vote_target is None or int(parts[2]) != pending_vote_target:
        await callback.answer("Bu tasdiqlash oynasi eskirgan.", show_alert=True)
        return
    target_id = pending_vote_target
    pending_vote_target = None
    if parts[1] == "yes":
        await callback.message.edit_text("👍 Ha — qaror tasdiqlandi.")
        await eliminate_voted_player(bot, target_id)
    else:
        await callback.message.edit_text("👎 Yo‘q — bu safar hech kim osilmadi.")
    is_night = True
    await callback.answer("Qaror qabul qilindi.")
    await continue_after_vote(bot)


async def night_phase(live_players: list, bot: Bot) -> None:
    global is_night, night_job
    is_night = True
    night_actions.clear()
    night_action_users.clear()
    silenced_people.clear()
    protected_people.clear()
    # PRO yoki oddiyligidan qat’i nazar, barcha o‘yinchilar guruhda yozishi mumkin.
    await safe_set_permissions(bot, registration.game_chat_id, True, use_independent_chat_permissions=True)
    for player in list(live_players):
        if isinstance(player, Don):
            await player.kill(bot)
        elif isinstance(player, Mafia):
            await player.vote_kill(bot)
        elif isinstance(player, Doctor):
            await player.heal(bot)
        elif isinstance(player, Commissioner):
            await player.commissioner_action(bot)
        elif isinstance(player, Kezuvchi):
            await player.sleep_drug(bot)
        elif isinstance(player, Advocate):
            await player.protect(bot)
        elif isinstance(player, Killer):
            await player.kill(bot)
        elif isinstance(player, Daydi):
            await player.visit(bot)
        else:
            await player.sleep(bot)
    _cancel_job(night_job)
    night_job = apscheduler.add_job(night_actions_result, DateTrigger(run_date=datetime.now() + timedelta(seconds=30)), args=[night_actions, bot])


@night_router.callback_query(NightCallback.filter())
async def night_actions_handler(callback: CallbackQuery, callback_data: NightCallback, bot: Bot):
    global commissioner_revealed
    if callback_data.day != day:
        await callback.answer("Bu tugma eskirgan.", show_alert=True)
        return

    # Afsungarning kunduzgi o‘limdan keyingi maxsus tanlovi.
    if callback_data.action == "sorcerer_kill":
        if callback.from_user.id not in pending_sorcerer:
            await callback.answer("Bu maxsus imkoniyat tugagan.", show_alert=True)
            return
        target = _live_player(callback_data.target)
        if not target:
            await callback.answer("Nishon o‘yinda yo‘q.", show_alert=True)
            return
        registration.live_players.remove(target)
        pending_sorcerer.discard(callback.from_user.id)
        await bot.send_message(registration.game_chat_id, f"🧞‍♂️ Afsungar {target}ni o‘zi bilan olib ketdi.")
        await callback.message.edit_reply_markup(reply_markup=None)
        await callback.answer("Qasos bajarildi.")
        return

    player = _live_player(callback.from_user.id)
    if not player:
        await callback.answer("Siz bu o‘yinda tirik o‘yinchi emassiz.", show_alert=True)
        return
    if callback_data.action == "sleep":
        await callback.answer("Tungi harakat kerak emas.")
        return
    if callback.from_user.id in night_action_users:
        await callback.answer("Bu tunda harakatingiz allaqachon qabul qilingan.", show_alert=True)
        return
    target = _live_player(callback_data.target)
    if not target:
        await callback.answer("Nishon o‘yinda yo‘q.", show_alert=True)
        return
    if callback_data.action in {"kill", "killer_kill", "commissioner_check", "commissioner_shoot", "sleep_drug", "daydi_visit"} and target.id == player.id:
        await callback.answer("O‘zingizni tanlay olmaysiz.", show_alert=True)
        return
    if callback_data.action == "commissioner_shoot" and day == 1:
        await callback.answer("Birinchi tunda tekshirmasdan otish taqiqlanadi.", show_alert=True)
        return
    if callback_data.action == "sleep_drug" and isinstance(target, Commissioner):
        await callback.answer("Kezuvchi Komissarni uxlatishi mumkin emas.", show_alert=True)
        return
    if callback_data.action == "heal" and target.id == player.id:
        if player.id in doctor_self_heal_used:
            await callback.answer("O‘zingizni faqat bir marta davolashingiz mumkin.", show_alert=True)
            return
        doctor_self_heal_used.add(player.id)

    if callback_data.action == "vote_kill":
        don = next((p for p in registration.live_players if isinstance(p, Don)), None)
        if don:
            await safe_send(bot, don.id, f"🔫 {player} {target}ni qurbon sifatida taklif qildi.")
    elif callback_data.action in {"kill", "killer_kill", "commissioner_shoot"}:
        if callback_data.action == "kill" and not isinstance(player, Don):
            await callback.answer("Faqat Don yakuniy qurbonni tanlaydi.", show_alert=True)
            return
        if callback_data.action == "kill":
            night_actions[:] = [a for a in night_actions if a.action != "kill"]
        night_actions.append(callback_data)
        if callback_data.action == "kill":
            logging.info("Don %s target tanladi: %s, night=%s", player.id, target.id, day)
            for mafia in (p for p in registration.live_players if isinstance(p, Mafia)):
                await safe_send(bot, mafia.id, f"👑 Don bu kecha {target}ni tanladi.")
    elif callback_data.action in {"heal", "sleep_drug", "advocate_protect", "daydi_visit"}:
        night_actions.append(callback_data)
    elif callback_data.action == "commissioner_check":
        commissioner_revealed = True
        role_label = getattr(target, "role_name", target.__class__.__name__)
        if isinstance(target, (Don, Mafia)) and _consume_item(target.id, "hujjat"):
            role_label = "Tinch aholi (soxta hujjat)"
            await safe_send(bot, target.id, "📄 Soxta hujjatingiz ishladi: Komissar sizni Tinch aholi deb ko‘rdi.")
        await callback.message.answer(f"🕵🏻‍♂ {target} — aniq roli: <b>{esc(role_label)}</b>.")
        await bot.send_message(registration.game_chat_id, "🕵🏻‍♂ Komissar o‘zini e’lon qildi. Doctor endi Komissarni davolashi mumkin.")
    night_action_users.add(callback.from_user.id)
    await callback.answer("✅ Tungi harakatingiz qabul qilindi.")
    try:
        await callback.message.edit_reply_markup(reply_markup=None)
    except Exception:
        pass


@day_router.callback_query(VoteCallback.filter())
async def vote_callback_handler(callback: CallbackQuery, callback_data: VoteCallback, bot: Bot):
    if callback_data.day != day:
        await callback.answer("Bu ovoz berish yakunlangan.", show_alert=True)
        return
    player = _live_player(callback.from_user.id)
    if not player:
        await callback.answer("Faqat tirik o‘yinchilar ovoz beradi.", show_alert=True)
        return
    if callback.from_user.id in silenced_people:
        await callback.answer("💃 Siz Kezuvchi tomonidan uxlatilgansiz va ovoz bera olmaysiz.", show_alert=True)
        return
    if callback_data.target == callback.from_user.id:
        await callback.answer("O‘zingizga ovoz berish mumkin emas.", show_alert=True)
        return
    voter_id = callback.from_user.id
    if voter_id in vote_choices:
        previous_target = vote_choices[voter_id]
        accused_people[previous_target] = accused_people.get(previous_target, 0) - 1
        if accused_people[previous_target] <= 0:
            accused_people.pop(previous_target, None)
    else:
        voted_people.append(voter_id)
    vote_choices[voter_id] = callback_data.target
    accused_people[callback_data.target] = accused_people.get(callback_data.target, 0) + 1
    await callback.answer("Ovozingiz qabul qilindi. Boshqa tugmani bosib ovozingizni o‘zgartirishingiz mumkin.")
    if len(voted_people) >= len(registration.live_players):
        await vote_process(bot)


# Geroy funksiyalari ovoz berish tugagach, yangi tun boshlanishidan oldin ishlaydi.
def hero_action_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🕶 O‘ldirish", callback_data="hero_attack_menu")],
        [InlineKeyboardButton(text="🛡 Himoyalanish", callback_data="hero_defend_menu")],
    ])


def hero_target_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for player in registration.live_players:
        builder.button(text=f"🕶 {player.full_name[:32]}", callback_data=f"hero_attack:{player.id}")
    builder.adjust(1)
    return builder.as_markup()


async def send_hero_actions(bot: Bot) -> None:
    with _hero_connection() as connection:
        owned_ids = {row["user_id"] for row in connection.execute("SELECT user_id FROM heroes WHERE owned=1")}
    for player in list(registration.live_players):
        if player.id in owned_ids:
            if isinstance(player, (Don, Mafia, Commissioner)):
                await safe_send(bot, player.id, "🕶 <b>Geroyingizdan foydalanish</b>\nNishonni tanlang:", reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                    [InlineKeyboardButton(text="🕶 O‘ldirish", callback_data="hero_attack_menu", style="danger")]
                ]))
            else:
                await safe_send(bot, player.id, "🕶 <b>Geroyingizdan himoyalanish</b>\nBu tun geroy hujumidan saqlanish uchun tugmani bosing:", reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                    [InlineKeyboardButton(text="🛡 Himoyalanish", callback_data="hero_defend_menu", style="success")]
                ]))


def _hero_connection():
    db_path = os.getenv("ECONOMY_DB", "economy.sqlite3")
    connection = sqlite3.connect(db_path)
    connection.row_factory = sqlite3.Row
    connection.execute("CREATE TABLE IF NOT EXISTS heroes (user_id INTEGER PRIMARY KEY, name TEXT NOT NULL DEFAULT 'Nomsiz', level INTEGER NOT NULL DEFAULT 1, power_min INTEGER NOT NULL DEFAULT 40, power_max INTEGER NOT NULL DEFAULT 47, defense INTEGER NOT NULL DEFAULT 0, max_defense INTEGER NOT NULL DEFAULT 0, charges INTEGER NOT NULL DEFAULT 10, points INTEGER NOT NULL DEFAULT 0, owned INTEGER NOT NULL DEFAULT 0)")
    connection.commit()
    return connection


@night_router.callback_query(F.data == "hero_attack_menu")
async def hero_attack_menu_callback(callback: CallbackQuery):
    if not _live_player(callback.from_user.id):
        await callback.answer("Faqat tirik o‘yinchi geroydan foydalana oladi.", show_alert=True)
        return
    if not isinstance(_live_player(callback.from_user.id), (Don, Mafia, Commissioner)):
        await callback.answer("Sizning rolingizda geroy bilan hujum qilish mumkin emas.", show_alert=True)
        return
    await callback.message.edit_text("🕶 <b>Hujum uchun o‘yinchini tanlang:</b>", reply_markup=hero_target_keyboard())
    await callback.answer()


@night_router.callback_query(F.data == "hero_defend_menu")
async def hero_defend_menu_callback(callback: CallbackQuery):
    player = _live_player(callback.from_user.id)
    if not player:
        await callback.answer("Faqat tirik o‘yinchi geroydan foydalana oladi.", show_alert=True)
        return
    with _hero_connection() as connection:
        hero = connection.execute("SELECT owned FROM heroes WHERE user_id=?", (player.id,)).fetchone()
    if not hero or not hero["owned"]:
        await callback.answer("Avval geroy sotib oling.", show_alert=True)
        return
    hero_guarded.add(player.id)
    await callback.message.edit_text("🛡 Geroyingiz himoyalanish holatiga o‘tdi. Bu tun sizni geroy hujumidan saqlaydi.")
    await callback.answer("Himoyalanish faollashdi.", show_alert=True)


@night_router.callback_query(F.data.startswith("hero_attack:"))
async def hero_attack_callback(callback: CallbackQuery):
    target_id = int(callback.data.split(":", 1)[1])
    attacker_player = _live_player(callback.from_user.id)
    target_player = _live_player(target_id)
    if not attacker_player or not target_player:
        await callback.answer("Faqat tirik o‘yinchilar geroy hujumidan foydalanadi.", show_alert=True)
        return
    if target_id == attacker_player.id:
        await callback.answer("Geroy bilan o‘zingizga hujum qila olmaysiz.", show_alert=True)
        return
    if not isinstance(attacker_player, (Don, Mafia, Commissioner)):
        await callback.answer("Sizning rolingizda geroy bilan hujum qilish mumkin emas.", show_alert=True)
        return
    with _hero_connection() as connection:
        connection.execute("INSERT OR IGNORE INTO heroes(user_id) VALUES (?)", (callback.from_user.id,))
        attacker = connection.execute("SELECT * FROM heroes WHERE user_id=?", (callback.from_user.id,)).fetchone()
        if not attacker["owned"]:
            await callback.answer("Avval /geroy orqali geroy sotib oling.", show_alert=True)
            return
        if attacker["charges"] <= 0:
            await callback.answer("Geroy zaryadi tugagan.", show_alert=True)
            return
        damage = min(100, (attacker["level"] * 100 + 29) // 30)
        connection.execute("UPDATE heroes SET charges=charges-1 WHERE user_id=?", (callback.from_user.id,))
    if target_id in hero_guarded:
        hero_guarded.discard(target_id)
        await callback.answer("🛡 Nishon geroy bilan himoyalangan edi. Hujum qaytarildi.", show_alert=True)
        return
    if _consume_item(target_id, "geroy_himoya"):
        await callback.answer("🟩 Geroydan himoya buyumi hujumni qaytardi.", show_alert=True)
        return
    new_health = max(0, player_health.get(target_id, 100) - damage)
    player_health[target_id] = new_health
    if new_health == 0:
        registration.live_players[:] = [player for player in registration.live_players if player.id != target_id]
        await callback.bot.send_message(registration.game_chat_id, f"🕶 <b>{target_player}</b> geroy hujumidan halok bo‘ldi.")
        await callback.message.edit_reply_markup(reply_markup=None)
        await _announce_end_or_continue(callback.bot)
        await callback.answer(f"{damage}% zarar berildi. Nishon o‘yindan chiqdi.", show_alert=True)
        return
    await callback.message.edit_reply_markup(reply_markup=None)
    await callback.answer(f"🕶 Geroy hujumi: {damage}% zarar. Nishon joni: {new_health}%.", show_alert=True)


@night_router.callback_query(F.data.startswith("hero_defend:"))
async def hero_defend_callback(callback: CallbackQuery):
    if not _live_player(callback.from_user.id):
        await callback.answer("Faqat tirik o‘yinchi geroydan foydalana oladi.", show_alert=True)
        return
    with _hero_connection() as connection:
        connection.execute("INSERT OR IGNORE INTO heroes(user_id) VALUES (?)", (callback.from_user.id,))
        hero = connection.execute("SELECT * FROM heroes WHERE user_id=?", (callback.from_user.id,)).fetchone()
        if not hero["owned"]:
            await callback.answer("Avval /geroy orqali geroy sotib oling.", show_alert=True)
            return
        if hero["max_defense"] <= 0:
            await callback.answer("Avval /geroy bo‘limida himoyani yangilang.", show_alert=True)
            return
        new_defense = min(hero["max_defense"], hero["defense"] + max(5, hero["level"] * 2))
        connection.execute("UPDATE heroes SET defense=? WHERE user_id=?", (new_defense, callback.from_user.id))
    await callback.answer(f"🛡 Geroy himoyasi faollashdi: {new_defense}/{hero['max_defense']}.", show_alert=True)


@day_router.message()
async def daytime_chat_filter(message: Message):
    if not registration.game_start or is_night:
        return
    live_player = _live_player(message.from_user.id)
    if live_player is None or message.from_user.id in silenced_people or not economy.is_pro_active(message.from_user.id):
        try:
            await message.delete()
        except Exception:
            pass
