from aiogram import Bot, F, Router
from aiogram.types import CallbackQuery

from handlers import registration
from callbacks import game_process
import keyboards as kb


game_settings_router = Router(name="game_settings_router")

count_roles = 0
count_mafies = 0
count_doctors = 0
count_sheriffs = 0
active_roles = []

roles = [
    "mafia", "don", "doctor", "peaceful man", "kezuvchi", "sergeant", "commissioner",
    "daydi", "sorcerer", "advocate", "killer", "wolf",
]

# Foydalanuvchi yuborgan birinchi ro‘yxatdagi 12 ta rol. O‘yinchi soni oshgani sari
# qo‘shimcha rollar bosqichma-bosqich qo‘shiladi; 12 kishida barcha rollar ishlaydi.
config_roles = {
    4: ["don", "mafia", "doctor", "peaceful man"],
    5: ["don", "mafia", "doctor", "commissioner", "peaceful man"],
    6: ["don", "mafia", "doctor", "commissioner", "sergeant", "peaceful man"],
    7: ["don", "mafia", "doctor", "commissioner", "kezuvchi", "sergeant", "peaceful man"],
    8: ["don", "mafia", "doctor", "commissioner", "kezuvchi", "sergeant", "daydi", "peaceful man"],
    9: ["don", "mafia", "doctor", "commissioner", "kezuvchi", "sergeant", "daydi", "sorcerer", "peaceful man"],
    10: ["don", "mafia", "doctor", "commissioner", "kezuvchi", "sergeant", "daydi", "sorcerer", "advocate", "peaceful man"],
    11: ["don", "mafia", "doctor", "commissioner", "kezuvchi", "sergeant", "daydi", "sorcerer", "advocate", "killer", "peaceful man"],
    12: ["don", "mafia", "doctor", "commissioner", "kezuvchi", "sergeant", "daydi", "sorcerer", "advocate", "killer", "wolf", "peaceful man"],
}


def save_roles():
    global active_roles
    player_count = len(registration.active_users)
    active_roles.clear()
    if player_count in config_roles:
        active_roles.extend(config_roles[player_count])
    else:
        # 12 kishidan ko‘p bo‘lsa, har 3 qo‘shimcha o‘yinchiga yana Mafia yoki Tinch aholi qo‘shiladi.
        base = list(config_roles[12])
        extra = player_count - 12
        base.extend(["peaceful man"] * extra)
        active_roles.extend(base)
    active_roles = active_roles[:player_count]


@game_settings_router.callback_query(F.data == "manual_settings")
async def settings_game(callback: CallbackQuery):
    await callback.message.edit_text("⚙️ Rollar sozlamalari:", reply_markup=kb.manual_role_settings_keyboard)
    await callback.answer()


@game_settings_router.callback_query(F.data == "save_settings")
async def save_changes(callback: CallbackQuery):
    await callback.message.edit_text("⚙️ Sozlamalar saqlandi. O‘yinni boshlashga tayyor.", reply_markup=kb.select_settings_keyboard)
    await callback.answer()


@game_settings_router.callback_query(F.data == "start_game")
async def start_game(callback: CallbackQuery, bot: Bot):
    started, response = await registration.start_existing_game(bot, callback.message.chat.id)
    await callback.answer(response, show_alert=not started)


@game_settings_router.callback_query(F.data == "edit_mafia")
async def edit_mafia_count(callback: CallbackQuery):
    await callback.message.edit_text(f"🔫 Mafia soni: {count_mafies}", reply_markup=kb.edit_mafia_keyboard)
    await callback.answer()


@game_settings_router.callback_query(F.data == "plus_mafia")
async def plus_mafia_func(callback: CallbackQuery):
    global count_mafies, count_roles
    if count_roles >= len(registration.active_users):
        await callback.answer("Rollar soni o‘yinchilar sonidan oshib ketdi.", show_alert=True)
        return
    count_roles += 1
    count_mafies += 1
    await callback.message.edit_text(f"🔫 Mafia soni: {count_mafies}", reply_markup=kb.edit_mafia_keyboard)
    await callback.answer()


@game_settings_router.callback_query(F.data == "minus_mafia")
async def minus_mafia_func(callback: CallbackQuery):
    global count_mafies, count_roles
    if count_mafies > 0:
        count_mafies -= 1
        count_roles = max(0, count_roles - 1)
    await callback.message.edit_text(f"🔫 Mafia soni: {count_mafies}", reply_markup=kb.edit_mafia_keyboard)
    await callback.answer()


@game_settings_router.callback_query(F.data == "edit_doctor")
async def edit_doctor_count(callback: CallbackQuery):
    await callback.message.edit_text(f"💊 Shifokor soni: {count_doctors}", reply_markup=kb.edit_doctor_keyboard)
    await callback.answer()


@game_settings_router.callback_query(F.data == "plus_doctor")
async def plus_doctor_func(callback: CallbackQuery):
    global count_doctors, count_roles
    if count_roles >= len(registration.active_users):
        await callback.answer("Rollar soni o‘yinchilar sonidan oshib ketdi.", show_alert=True)
        return
    count_roles += 1
    count_doctors += 1
    await callback.message.edit_text(f"💊 Shifokor soni: {count_doctors}", reply_markup=kb.edit_doctor_keyboard)
    await callback.answer()


@game_settings_router.callback_query(F.data == "minus_doctor")
async def minus_doctor_func(callback: CallbackQuery):
    global count_doctors, count_roles
    if count_doctors > 0:
        count_doctors -= 1
        count_roles = max(0, count_roles - 1)
    await callback.message.edit_text(f"💊 Shifokor soni: {count_doctors}", reply_markup=kb.edit_doctor_keyboard)
    await callback.answer()


@game_settings_router.callback_query(F.data == "edit_sheriff")
async def edit_sheriff_count(callback: CallbackQuery):
    await callback.message.edit_text(f"🕵️ Komissar katani soni: {count_sheriffs}", reply_markup=kb.edit_sheriff_keyboard)
    await callback.answer()


@game_settings_router.callback_query(F.data == "plus_sheriff")
async def plus_sheriff_func(callback: CallbackQuery):
    global count_sheriffs, count_roles
    if count_roles >= len(registration.active_users):
        await callback.answer("Rollar soni o‘yinchilar sonidan oshib ketdi.", show_alert=True)
        return
    count_roles += 1
    count_sheriffs += 1
    await callback.message.edit_text(f"🕵️ Komissar katani soni: {count_sheriffs}", reply_markup=kb.edit_sheriff_keyboard)
    await callback.answer()


@game_settings_router.callback_query(F.data == "minus_sheriff")
async def minus_sheriff_func(callback: CallbackQuery):
    global count_sheriffs, count_roles
    if count_sheriffs > 0:
        count_sheriffs -= 1
        count_roles = max(0, count_roles - 1)
    await callback.message.edit_text(f"🕵️ Komissar katani soni: {count_sheriffs}", reply_markup=kb.edit_sheriff_keyboard)
    await callback.answer()


@game_settings_router.callback_query(F.data == "go_back")
async def go_back_func(callback: CallbackQuery):
    await callback.message.edit_text("⚙️ O‘yinni boshlash sozlamalari:", reply_markup=kb.manual_role_settings_keyboard)
    await callback.answer()
