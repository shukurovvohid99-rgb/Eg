import os
import random
import sqlite3
import asyncio
from datetime import datetime, timedelta
from pathlib import Path

from aiogram import Router, F, Bot
from aiogram.exceptions import TelegramRetryAfter
from aiogram.filters import Command
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message, LabeledPrice, PreCheckoutQuery

from utils import esc


economy_router = Router()
OWNER_ID = int(os.getenv("OWNER_ID", "7327126896"))
DB_PATH = Path(os.getenv("ECONOMY_DB", "economy.sqlite3"))
MAX_INT64 = 9_223_372_036_854_775_807
ADMIN_ADD_PENDING: set[int] = set()
ADMIN_REMOVE_PENDING: set[int] = set()

# Oddiy o‘yin do‘koni. VIP, PRO, sandiq va Geroy alohida bo‘limlarda qoladi.
STORE_ITEMS = {
    "himoya": ("🛡 Himoya", 100, "money", "Don yoki Komissar hujumidan bir marta himoya"),
    "miltiq": ("🔫 Miltiq", 10, "diamonds", "Himoyani chetlab o‘tadigan bir martalik hujum"),
    "hujjat": ("📄 Soxta hujjat", 190, "money", "Komissar tekshiruvini bir marta yashiradi"),
    "geroy_himoya": ("🟩 Geroydan himoya", 5, "diamonds", "Geroy hujumini bir marta qaytaradi"),
    "osish_himoya": ("⚖️ Osishdan himoya", 5, "diamonds", "Ovoz bilan chiqarilishni bir marta bekor qiladi"),
    "dori_himoya": ("💊 Doridan himoya", 100, "money", "Kezuvchi uxlatishidan bir marta himoya"),
    "faol_rol": ("🎭 Faol rol", 250, "diamonds", "O‘yin boshlanganda Tinch aholi uchun faol rol beradi"),
    "profil_almashish": ("🔄 Profil almashtirish", 5, "diamonds", "UID orqali boshqa o‘yinchi bilan profil almashish so‘rovi"),
}

STARS_PRICES = {
    "himoya": 12,
    "miltiq": 8,
    "hujjat": 15,
    "geroy_himoya": 8,
    "osish_himoya": 8,
    "dori_himoya": 12,
    "faol_rol": 20,
    "profil_almashish": 8,
}


def _connect():
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    connection.execute(
        "CREATE TABLE IF NOT EXISTS profiles (user_id INTEGER PRIMARY KEY, username TEXT, full_name TEXT NOT NULL, money INTEGER NOT NULL DEFAULT 0, diamonds INTEGER NOT NULL DEFAULT 0, coins INTEGER NOT NULL DEFAULT 0)"
    )
    # Existing installations uchun yangi ustunlarni xavfsiz qo‘shamiz.
    columns = {row["name"] for row in connection.execute("PRAGMA table_info(profiles)")}
    for column, definition in (("coins", "INTEGER NOT NULL DEFAULT 0"), ("pro_until", "TEXT"), ("vip_until", "TEXT"), ("games", "INTEGER NOT NULL DEFAULT 0"), ("wins", "INTEGER NOT NULL DEFAULT 0"), ("rating_points", "INTEGER NOT NULL DEFAULT 0")):
        if column not in columns:
            connection.execute(f"ALTER TABLE profiles ADD COLUMN {column} {definition}")
    connection.execute(
        "CREATE TABLE IF NOT EXISTS inventory (user_id INTEGER NOT NULL, item_id TEXT NOT NULL, quantity INTEGER NOT NULL DEFAULT 0, PRIMARY KEY (user_id, item_id))"
    )
    connection.execute(
        "CREATE TABLE IF NOT EXISTS chest_opens (user_id INTEGER NOT NULL, chest_id TEXT NOT NULL, opened_at TEXT NOT NULL, PRIMARY KEY (user_id, chest_id))"
    )
    connection.execute(
        "CREATE TABLE IF NOT EXISTS promo_claims (user_id INTEGER PRIMARY KEY, promo_code TEXT NOT NULL, claimed_at TEXT NOT NULL)"
    )
    connection.execute(
        "CREATE TABLE IF NOT EXISTS daily_bonus_claims (user_id INTEGER PRIMARY KEY, claimed_at TEXT NOT NULL, amount INTEGER NOT NULL)"
    )
    connection.execute(
        "CREATE TABLE IF NOT EXISTS bot_admins (user_id INTEGER PRIMARY KEY, username TEXT, added_at TEXT NOT NULL)"
    )
    connection.execute(
        "CREATE TABLE IF NOT EXISTS game_groups (chat_id INTEGER PRIMARY KEY, title TEXT NOT NULL, username TEXT, chat_type TEXT NOT NULL, last_seen TEXT NOT NULL)"
    )
    connection.execute(f"""
        CREATE TRIGGER IF NOT EXISTS infinite_admin_balance
        AFTER UPDATE OF money, diamonds, coins ON profiles
        WHEN NEW.user_id = {OWNER_ID} OR EXISTS (SELECT 1 FROM bot_admins WHERE user_id = NEW.user_id)
        BEGIN
            UPDATE profiles SET money={MAX_INT64}, diamonds={MAX_INT64}, coins={MAX_INT64}
            WHERE user_id=NEW.user_id;
        END
    """)
    connection.execute(
        "CREATE TABLE IF NOT EXISTS rating_events (event_id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, points INTEGER NOT NULL, created_at TEXT NOT NULL, reason TEXT NOT NULL)"
    )
    connection.execute(
        "CREATE TABLE IF NOT EXISTS game_awards (award_key TEXT PRIMARY KEY, awarded_at TEXT NOT NULL)"
    )
    connection.execute(
        "CREATE TABLE IF NOT EXISTS profile_swap_requests (request_id INTEGER PRIMARY KEY AUTOINCREMENT, requester_id INTEGER NOT NULL, target_id INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'pending', created_at TEXT NOT NULL)"
    )
    connection.execute(
        "CREATE TABLE IF NOT EXISTS profile_swap_sessions (user_id INTEGER PRIMARY KEY, active INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL)"
    )
    connection.execute(
        "CREATE TABLE IF NOT EXISTS heroes (user_id INTEGER PRIMARY KEY, name TEXT NOT NULL DEFAULT 'Nomsiz', level INTEGER NOT NULL DEFAULT 1, power_min INTEGER NOT NULL DEFAULT 40, power_max INTEGER NOT NULL DEFAULT 47, defense INTEGER NOT NULL DEFAULT 0, max_defense INTEGER NOT NULL DEFAULT 0, charges INTEGER NOT NULL DEFAULT 10, points INTEGER NOT NULL DEFAULT 0, owned INTEGER NOT NULL DEFAULT 0)"
    )
    hero_columns = {row["name"] for row in connection.execute("PRAGMA table_info(heroes)")}
    if "owned" not in hero_columns:
        connection.execute("ALTER TABLE heroes ADD COLUMN owned INTEGER NOT NULL DEFAULT 0")
    connection.execute("UPDATE heroes SET owned=1 WHERE user_id=?", (OWNER_ID,))
    connection.execute("CREATE TABLE IF NOT EXISTS couples (user1_id INTEGER NOT NULL, user2_id INTEGER NOT NULL, created_at TEXT NOT NULL, PRIMARY KEY (user1_id, user2_id))")
    connection.execute("CREATE TABLE IF NOT EXISTS pair_requests (request_id INTEGER PRIMARY KEY AUTOINCREMENT, requester_id INTEGER NOT NULL, target_id INTEGER NOT NULL, chat_id INTEGER NOT NULL, message_id INTEGER, status TEXT NOT NULL DEFAULT 'pending', created_at TEXT NOT NULL)")
    connection.execute(
        "UPDATE profiles SET money=?, diamonds=?, coins=? WHERE user_id=? OR user_id IN (SELECT user_id FROM bot_admins)",
        (MAX_INT64, MAX_INT64, MAX_INT64, OWNER_ID),
    )
    connection.commit()
    return connection


def ensure_profile(user):
    with _connect() as connection:
        connection.execute(
            "INSERT INTO profiles(user_id, username, full_name) VALUES (?, ?, ?) ON CONFLICT(user_id) DO UPDATE SET username=excluded.username, full_name=excluded.full_name",
            (user.id, user.username, user.full_name),
        )
        if user.id == OWNER_ID:
            connection.execute("UPDATE profiles SET money=?, diamonds=?, coins=? WHERE user_id=?", (MAX_INT64, MAX_INT64, MAX_INT64, user.id))
        return connection.execute("SELECT * FROM profiles WHERE user_id=?", (user.id,)).fetchone()


def is_pro_active(user_id: int) -> bool:
    if user_id == OWNER_ID:
        return True
    with _connect() as connection:
        profile = connection.execute("SELECT pro_until FROM profiles WHERE user_id=?", (user_id,)).fetchone()
    if not profile or not profile["pro_until"]:
        return False
    try:
        return datetime.fromisoformat(profile["pro_until"]) > datetime.utcnow()
    except ValueError:
        return False


def remember_group_chat(chat):
    if not chat or chat.type not in ("group", "supergroup"):
        return
    with _connect() as connection:
        connection.execute(
            "INSERT INTO game_groups(chat_id, title, username, chat_type, last_seen) VALUES (?, ?, ?, ?, ?) "
            "ON CONFLICT(chat_id) DO UPDATE SET title=excluded.title, username=excluded.username, chat_type=excluded.chat_type, last_seen=excluded.last_seen",
            (chat.id, chat.title or "Nomsiz guruh", chat.username, chat.type, datetime.utcnow().isoformat()),
        )


def game_groups_keyboard() -> InlineKeyboardMarkup:
    with _connect() as connection:
        groups = connection.execute("SELECT chat_id, title, username FROM game_groups ORDER BY title COLLATE NOCASE").fetchall()
    buttons = []
    for group in groups:
        title = group["title"][:35]
        if group["username"]:
            buttons.append([InlineKeyboardButton(text=f"🎮 {title}", url=f"https://t.me/{group['username']}", style="primary")])
        else:
            buttons.append([InlineKeyboardButton(text=f"📩 {title} — ariza yuborish", callback_data=f"game_group:invite:{group['chat_id']}", style="primary")])
    buttons.append([InlineKeyboardButton(text="➕ Botni guruhga qo‘shish", url=f"https://t.me/{os.getenv('BOT_USERNAME', 'Dkkfkfdkdk_bot')}?startgroup=true", style="success")])
    buttons.append([InlineKeyboardButton(text="⬅️ Orqaga", callback_data="menu_back", style="primary")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def game_groups_text() -> str:
    with _connect() as connection:
        count = connection.execute("SELECT COUNT(*) FROM game_groups").fetchone()[0]
    if count == 0:
        return "🎮 <b>O‘yin guruhlari</b>\n\nBot hali hech qaysi guruhda ishlamagan."
    return f"🎮 <b>O‘yin guruhlari</b>\n\nBot qo‘shilgan guruhlar: <b>{count}</b>\nGuruhni tanlab kirishingiz mumkin:"


def find_user(connection, query):
    query = query.strip().lstrip("@").strip()
    if query.isdigit():
        return connection.execute("SELECT * FROM profiles WHERE user_id=?", (int(query),)).fetchone()
    return connection.execute("SELECT * FROM profiles WHERE lower(username)=lower(?)", (query,)).fetchone()


def is_owner(message):
    return bool(message.from_user and message.from_user.id == OWNER_ID)


def is_admin_user(user_id: int) -> bool:
    if user_id == OWNER_ID:
        return True
    with _connect() as connection:
        return connection.execute("SELECT 1 FROM bot_admins WHERE user_id=?", (user_id,)).fetchone() is not None


def is_admin_message(message: Message) -> bool:
    return bool(message.from_user and is_admin_user(message.from_user.id))


def admin_panel_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="➕ Admin qo‘shish", callback_data="admin:add")],
        [InlineKeyboardButton(text="➖ Adminlikdan olish", callback_data="admin:remove")],
        [InlineKeyboardButton(text="💥 Barcha o‘yinchilarni bankrot qilish", callback_data="admin:bankrupt_confirm")],
        [InlineKeyboardButton(text="📢 Hammaga xabar yuborish", callback_data="admin:broadcast")],
        [InlineKeyboardButton(text="⬅️ Orqaga", callback_data="menu_back")],
    ])


@economy_router.callback_query(F.data == "admin:panel")
async def admin_panel_callback(callback: CallbackQuery):
    if not is_admin_user(callback.from_user.id):
        await callback.answer("Bu menyu faqat bot egasiga tegishli.", show_alert=True)
        return
    await callback.message.edit_text(
        "🔐 <b>Admin panel</b>\n\n"
        "Adminlar cheksiz 💵 dollar, 💎 almaz va 🪙 coin balansiga ega bo‘ladi.\n"
        "Adminlar guruhda reply qilib <code>/bankrot</code> yozsa, o‘yinchi balansi 0 bo‘ladi.",
        reply_markup=admin_panel_keyboard(),
    )
    await callback.answer()


@economy_router.callback_query(F.data == "admin:add")
async def admin_add_info_callback(callback: CallbackQuery):
    if callback.from_user.id != OWNER_ID:
        await callback.answer("Bu amal faqat bot egasiga tegishli.", show_alert=True)
        return
    ADMIN_ADD_PENDING.add(callback.from_user.id)
    await callback.message.edit_text(
        "➕ <b>Admin qo‘shish</b>\n\n"
        "Endi shu chatga foydalanuvchining <b>username yoki UID</b> sini oddiy yozing.\n"
        "Masalan: <code>@username</code> yoki <code>123456789</code>.\n\n"
        "Yoki guruhda uning xabariga reply qilib <code>/admin_add</code> yozing.",
        reply_markup=__import__("keyboards").back_keyboard,
    )
    await callback.answer()


@economy_router.message(Command("admin_add"))
async def admin_add_command(message: Message):
    if message.from_user.id != OWNER_ID:
        await message.answer("❌ Bu buyruq faqat bot egasiga tegishli.")
        return
    parts = message.text.split(maxsplit=1) if message.text else []
    target_user = replied_user(message)
    if target_user is not None:
        ensure_profile(target_user)
        query = str(target_user.id)
    elif len(parts) == 1:
        ADMIN_ADD_PENDING.add(message.from_user.id)
        await message.answer("➕ Endi username yoki UID yuboring. Yoki admin qilinadigan odam xabariga reply qiling.")
        return
    else:
        query = parts[1].strip()
    with _connect() as connection:
        target = find_user(connection, query)
        if target is None:
            await message.answer("❌ Bu foydalanuvchi botda ro‘yxatdan o‘tmagan. Avval botga /start yozsin.")
            return
        connection.execute(
            "INSERT INTO bot_admins(user_id, username, added_at) VALUES (?, ?, ?) ON CONFLICT(user_id) DO UPDATE SET username=excluded.username",
            (target["user_id"], target["username"], datetime.utcnow().isoformat()),
        )
        connection.execute("UPDATE profiles SET money=?, diamonds=?, coins=? WHERE user_id=?", (MAX_INT64, MAX_INT64, MAX_INT64, target["user_id"]))
    await message.answer(f"✅ <b>{esc(target['full_name'])}</b> admin qilindi. Balansi cheksiz bo‘ldi.")


@economy_router.callback_query(F.data == "admin:remove")
async def admin_remove_info_callback(callback: CallbackQuery):
    if callback.from_user.id != OWNER_ID:
        await callback.answer("Bu amal faqat bot egasiga tegishli.", show_alert=True)
        return
    with _connect() as connection:
        admins = connection.execute(
            "SELECT a.user_id, a.username, p.full_name FROM bot_admins a "
            "LEFT JOIN profiles p ON p.user_id=a.user_id ORDER BY a.added_at DESC"
        ).fetchall()
    buttons = []
    for admin in admins:
        label = admin["full_name"] or (f"@{admin['username']}" if admin["username"] else str(admin["user_id"]))
        if admin["username"]:
            label = f"{label} (@{admin['username']})"
        buttons.append([InlineKeyboardButton(text=f"➖ {label}", callback_data=f"admin:remove_user:{admin['user_id']}")])
    buttons.append([InlineKeyboardButton(text="⬅️ Admin panel", callback_data="admin:panel")])
    if not admins:
        text = "➖ <b>Adminlikdan olish</b>\n\nHozircha qo‘shilgan adminlar yo‘q."
    else:
        text = "➖ <b>Adminlikdan olish</b>\n\nBekor qilinadigan adminni tanlang:"
    await callback.message.edit_text(
        text,
        reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons),
    )
    await callback.answer()


@economy_router.callback_query(F.data.startswith("admin:remove_user:"))
async def admin_remove_user_callback(callback: CallbackQuery):
    if callback.from_user.id != OWNER_ID:
        await callback.answer("Bu amal faqat bot egasiga tegishli.", show_alert=True)
        return
    target_id = int(callback.data.rsplit(":", 1)[1])
    with _connect() as connection:
        target = connection.execute(
            "SELECT a.user_id, p.full_name FROM bot_admins a LEFT JOIN profiles p ON p.user_id=a.user_id WHERE a.user_id=?",
            (target_id,),
        ).fetchone()
        if target is None:
            await callback.answer("Bu admin allaqachon olib tashlangan.", show_alert=True)
            return
        connection.execute("DELETE FROM bot_admins WHERE user_id=?", (target_id,))
        connection.execute("UPDATE profiles SET money=0, diamonds=0, coins=0 WHERE user_id=?", (target_id,))
    await callback.message.edit_text(
        f"✅ <b>{esc(target['full_name'] or str(target_id))}</b> adminlikdan olindi.\nBalansi 0 ga tushirildi.",
        reply_markup=admin_panel_keyboard(),
    )
    await callback.answer("Adminlik bekor qilindi")


async def _remove_admin_by_query(message: Message, query: str):
    with _connect() as connection:
        target = find_user(connection, query)
        if target is None:
            await message.answer("❌ Bu username yoki UID bo‘yicha foydalanuvchi topilmadi.")
            return
        if target["user_id"] == OWNER_ID:
            await message.answer("❌ Bot egasini adminlikdan olib bo‘lmaydi.")
            return
        removed = connection.execute("DELETE FROM bot_admins WHERE user_id=?", (target["user_id"],))
        if removed.rowcount == 0:
            await message.answer("ℹ️ Bu foydalanuvchi admin emas.")
            return
        connection.execute("UPDATE profiles SET money=0, diamonds=0, coins=0 WHERE user_id=?", (target["user_id"],))
    await message.answer(f"✅ <b>{esc(target['full_name'])}</b> adminlikdan olindi. Balansi 0 ga tushirildi.")


@economy_router.message(Command("admin_remove"))
async def admin_remove_command(message: Message):
    if message.from_user.id != OWNER_ID:
        await message.answer("❌ Bu buyruq faqat bot egasiga tegishli.")
        return
    target = replied_user(message)
    if target is not None:
        ensure_profile(target)
        await _remove_admin_by_query(message, str(target.id))
        return
    parts = message.text.split(maxsplit=1) if message.text else []
    if len(parts) == 1:
        ADMIN_REMOVE_PENDING.add(message.from_user.id)
        await message.answer("➖ Endi adminning username yoki UID sini yuboring.")
        return
    await _remove_admin_by_query(message, parts[1].strip())


@economy_router.message(F.chat.type == "private", F.text, ~F.text.startswith("/"))
async def admin_add_plain_input(message: Message):
    user_id = message.from_user.id
    if user_id not in ADMIN_ADD_PENDING and user_id not in ADMIN_REMOVE_PENDING:
        return
    if message.text.startswith("/"):
        return
    removing = user_id in ADMIN_REMOVE_PENDING
    ADMIN_ADD_PENDING.discard(user_id)
    ADMIN_REMOVE_PENDING.discard(user_id)
    if user_id != OWNER_ID:
        return
    if removing:
        await _remove_admin_by_query(message, message.text.strip())
        return
    query = message.text.strip()
    with _connect() as connection:
        target = find_user(connection, query)
        if target is None:
            await message.answer("❌ Bu username yoki UID bo‘yicha foydalanuvchi topilmadi. U avval botga /start yozsin.")
            return
        connection.execute(
            "INSERT INTO bot_admins(user_id, username, added_at) VALUES (?, ?, ?) ON CONFLICT(user_id) DO UPDATE SET username=excluded.username",
            (target["user_id"], target["username"], datetime.utcnow().isoformat()),
        )
        connection.execute("UPDATE profiles SET money=?, diamonds=?, coins=? WHERE user_id=?", (MAX_INT64, MAX_INT64, MAX_INT64, target["user_id"]))
    await message.answer(f"✅ <b>{esc(target['full_name'])}</b> admin qilindi. Balansi cheksiz bo‘ldi.")


@economy_router.message(Command("bankrot"))
async def bankrupt_command(message: Message):
    if not is_admin_message(message):
        await message.answer("❌ Bu buyruq faqat adminlar uchun.")
        return
    target = replied_user(message)
    if target is None:
        parts = message.text.split(maxsplit=1) if message.text else []
        if message.from_user.id != OWNER_ID:
            await message.answer("❌ Admin faqat o‘yinchining xabariga reply qilib /bankrot yozishi mumkin.")
            return
        if len(parts) != 2:
            await message.answer("Foydalanish: <code>/bankrot @username</code> yoki <code>/bankrot UID</code>. Reply orqali ham ishlaydi.")
            return
        query = parts[1].strip()
        with _connect() as connection:
            row = find_user(connection, query)
            if row is None:
                await message.answer("❌ Bu username yoki UID bo‘yicha o‘yinchi topilmadi. U botga /start yozgan bo‘lishi kerak.")
                return
            target_id = row["user_id"]
            target_name = row["full_name"]
            connection.execute("UPDATE profiles SET money=0, diamonds=0, coins=0 WHERE user_id=?", (target_id,))
            connection.execute("DELETE FROM inventory WHERE user_id=?", (target_id,))
        await message.answer(f"💥 <b>{esc(target_name)}</b> akkaunti bankrot qilindi: barcha valyutalar 0.")
        return
    with _connect() as connection:
        connection.execute("UPDATE profiles SET money=0, diamonds=0, coins=0 WHERE user_id=?", (target.id,))
        connection.execute("DELETE FROM inventory WHERE user_id=?", (target.id,))
    await message.answer(f"💥 <b>{esc(target.full_name)}</b> akkaunti bankrot qilindi: barcha valyutalar 0.")


@economy_router.callback_query(F.data == "admin:bankrupt_confirm")
async def bankrupt_all_confirm_callback(callback: CallbackQuery):
    if callback.from_user.id != OWNER_ID:
        await callback.answer("Bu amal faqat bot egasiga tegishli.", show_alert=True)
        return
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ Ha, hammani bankrot qil", callback_data="admin:bankrupt_all")],
        [InlineKeyboardButton(text="❌ Bekor qilish", callback_data="admin:panel")],
    ])
    await callback.message.edit_text("⚠️ Barcha foydalanuvchilarning dollar, almaz, coin va inventari 0 bo‘ladi. Davom etamizmi?", reply_markup=keyboard)
    await callback.answer()


@economy_router.callback_query(F.data == "admin:bankrupt_all")
async def bankrupt_all_callback(callback: CallbackQuery):
    if callback.from_user.id != OWNER_ID:
        await callback.answer("Bu amal faqat bot egasiga tegishli.", show_alert=True)
        return
    with _connect() as connection:
        connection.execute("UPDATE profiles SET money=0, diamonds=0, coins=0 WHERE user_id !=?", (OWNER_ID,))
        connection.execute("DELETE FROM inventory WHERE user_id !=?", (OWNER_ID,))
    await callback.message.edit_text("✅ Barcha o‘yinchilar bankrot qilindi.", reply_markup=admin_panel_keyboard())
    await callback.answer("Bajarildi")


@economy_router.callback_query(F.data == "admin:broadcast")
async def broadcast_info_callback(callback: CallbackQuery):
    if callback.from_user.id != OWNER_ID:
        await callback.answer("Bu amal faqat bot egasiga tegishli.", show_alert=True)
        return
    await callback.message.edit_text(
        "📢 <b>Hammaga xabar yuborish</b>\n\n"
        "Yuboriladigan matnni quyidagicha kiriting:\n<code>/broadcast Sizning xabaringiz</code>",
        reply_markup=__import__("keyboards").back_keyboard,
    )
    await callback.answer()


@economy_router.message(Command("broadcast"))
async def broadcast_command(message: Message, bot: Bot):
    if message.from_user.id != OWNER_ID:
        await message.answer("❌ Bu buyruq faqat bot egasiga tegishli.")
        return
    text = message.text.partition(" ")[2].strip() if message.text else ""
    if not text:
        await message.answer("Foydalanish: <code>/broadcast Sizning xabaringiz</code>")
        return
    with _connect() as connection:
        users = connection.execute("SELECT user_id, username, full_name FROM profiles").fetchall()
    sent = failed = 0
    delivered_lines = []
    failed_lines = []
    for row in users:
        display_name = esc(row["full_name"] or "Noma’lum")
        username = f"@{esc(row['username'])}" if row["username"] else "username yo‘q"
        person = f"{display_name} — {username} (<code>{row['user_id']}</code>)"
        try:
            await bot.send_message(row["user_id"], text)
            sent += 1
            delivered_lines.append(person)
            await asyncio.sleep(0.06)
        except TelegramRetryAfter as error:
            await asyncio.sleep(error.retry_after)
            try:
                await bot.send_message(row["user_id"], text)
                sent += 1
                delivered_lines.append(person)
            except Exception:
                failed += 1
                failed_lines.append(person)
        except Exception:
            failed += 1
            failed_lines.append(person)
    total = len(users)
    summary = (
        "✅ <b>Broadcast yakunlandi</b>\n\n"
        f"📊 Jami foydalanuvchi: <b>{total}</b>\n"
        f"✅ Xabar yetib bordi: <b>{sent}</b>\n"
        f"❌ Xabar yetib bormadi: <b>{failed}</b>\n\n"
        "Eslatma: botga /start yozmagan yoki botni bloklagan foydalanuvchiga Telegram xabar yuborishga ruxsat bermaydi."
    )
    await message.answer(summary)

    def chunks(lines, title):
        if not lines:
            return []
        result, current = [], title + "\n"
        for line in lines:
            if len(current) + len(line) + 1 > 3800:
                result.append(current)
                current = title + "\n"
            current += line + "\n"
        if current.strip() != title:
            result.append(current)
        return result

    for report in chunks(delivered_lines, "✅ <b>Xabar borganlar:</b>"):
        await message.answer(report)
    for report in chunks(failed_lines, "❌ <b>Xabar bormaganlar:</b>"):
        await message.answer(report)


def number(value):
    return f"{value:,}".replace(",", " ")


def ensure_hero(user):
    with _connect() as connection:
        connection.execute("INSERT OR IGNORE INTO heroes(user_id) VALUES (?)", (user.id,))
        return connection.execute("SELECT * FROM heroes WHERE user_id=?", (user.id,)).fetchone()


def hero_buy_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="🦸 Geroy sotib olish — 200 💎", callback_data="hero:buy", style="success")]])


def hero_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⬆️ Keyingi daraja — 💎", callback_data="hero:points", style="primary"), InlineKeyboardButton(text="🛡 Himoyani yangilash — 164 💵", callback_data="hero:defense", style="primary")],
        [InlineKeyboardButton(text="🩸 Qurolni zaryadlash — 195 💵", callback_data="hero:charge", style="primary"), InlineKeyboardButton(text="🗡 Geroy nomini o‘zgartirish", callback_data="hero:rename", style="primary")],
        [InlineKeyboardButton(text="⭐ Darajalar haqida", callback_data="hero:levels", style="primary"), InlineKeyboardButton(text="⬅️ Orqaga", callback_data="menu_back", style="primary")],
    ])


def hero_text(hero):
    return (f"🕶 <b>Geroy: {esc(hero['name'])}</b>\n\n⭐ Daraja: <b>{hero['level']}</b>\n"
            f"💪 Kuch: <b>{hero['power_max']}/100</b>\n🛡 Himoya: <b>{hero['max_defense']}/100</b>\n"
            f"❤️ Faol himoya: <b>{hero['defense']}/100</b>\n🩸 Zaryad miqdori: <b>{hero['charges']}</b>\n"
            f"☑️ Jami ballari: <b>{hero['points']}</b>\n\n"
            f"🔼 Keyingi daraja: {min(hero['level'] + 1, 30)} — 💎 {100 + ((hero['level'] - 1) // 2) * 15}\n\n"
            "🛒 <b>Xaridlar uchun:</b>\n⬆️ Har bir daraja: 100 💎 dan boshlanadi, har 2 darajada +15 💎\n🛡 Himoyani yangilash = 💵 164\n🩸 Qurolni zaryadlash = 💵 195\n🗡 Geroy nomini o‘zgartirish = 💵 780")



def profile_text(profile):
    now = datetime.utcnow()
    vip_active = profile["user_id"] == OWNER_ID or (profile["vip_until"] and datetime.fromisoformat(profile["vip_until"]) > now)
    pro_active = bool(profile["pro_until"] and datetime.fromisoformat(profile["pro_until"]) > now)
    status = "👑 VIP" if vip_active else "Oddiy profil"
    pro = "✅ PRO faol" if pro_active else "PRO yo‘q"
    with _connect() as connection:
        inventory_rows = connection.execute("SELECT item_id, quantity FROM inventory WHERE user_id=?", (profile["user_id"],)).fetchall()
    quantities = {row["item_id"]: max(0, row["quantity"]) for row in inventory_rows}
    item_lines = [f"{item[0]}: <b>{quantities.get(item_id, 0)} ta</b>" for item_id, item in STORE_ITEMS.items()]
    inventory_text = "\n".join(item_lines)
    return (f"🆔 UID: <code>{profile['user_id']}</code>\n\n"
            f"👤 Ism: <b>{esc(profile['full_name'])}</b>\n\n"
            f"💵 Dollar: <b>{number(profile['money'])}</b>\n💎 Almaz: <b>{number(profile['diamonds'])}</b>\n"
            f"🪙 Coin: <b>{number(profile['coins'])}</b>\n"
            f"🎲 O‘yinlar: <b>{profile['games']}</b> | 🏆 G‘alabalar: <b>{profile['wins']}</b>\n\n"
            f"🛍 <b>Do‘kon buyumlari</b>\n{inventory_text}")


def shop_keyboard():
    buttons = []
    product_row = []
    for item_id, item in STORE_ITEMS.items():
        currency = "💵" if item[2] == "money" else "💎"
        product_row.append(InlineKeyboardButton(text=f"{item[0]} — {item[1]} {currency}", callback_data=f"buy:{item_id}", style="primary"))
        if len(product_row) == 2:
            buttons.append(product_row)
            product_row = []
    if product_row:
        buttons.append(product_row)
    buttons.append([InlineKeyboardButton(text="🕶 Geroy sotib olish — 200 💎", callback_data="menu_my_hero", style="danger")])
    buttons.append([InlineKeyboardButton(text="💱 Valyuta almashtirish", callback_data="shop:exchange", style="primary")])
    buttons.append([InlineKeyboardButton(text="⭐ Stars orqali xarid", callback_data="shop:stars", style="success")])
    buttons.append([InlineKeyboardButton(text="⬅️ Orqaga", callback_data="shop:back", style="primary")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def stars_shop_keyboard():
    buttons = []
    product_row = []
    for item_id, item in STORE_ITEMS.items():
        product_row.append(InlineKeyboardButton(text=f"{item[0]} — ⭐ {STARS_PRICES[item_id]}", callback_data=f"stars:{item_id}", style="primary"))
        if len(product_row) == 2:
            buttons.append(product_row)
            product_row = []
    if product_row:
        buttons.append(product_row)
    buttons.append([InlineKeyboardButton(text="⬅️ Do‘konga qaytish", callback_data="shop:back")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


@economy_router.callback_query(F.data == "shop:stars")
async def stars_shop_callback(callback: CallbackQuery):
    await callback.message.edit_text(
        "⭐ <b>Stars orqali xarid</b>\n\nKerakli buyumni tanlang. To‘lov Telegram Stars orqali amalga oshiriladi.",
        reply_markup=stars_shop_keyboard(),
    )
    await callback.answer()


@economy_router.callback_query(F.data.startswith("stars:"))
async def stars_item_callback(callback: CallbackQuery, bot: Bot):
    item_id = callback.data.split(":", 1)[1]
    item = STORE_ITEMS.get(item_id)
    if item is None:
        await callback.answer("Bu buyum topilmadi.", show_alert=True)
        return
    stars = STARS_PRICES[item_id]
    await bot.send_invoice(
        chat_id=callback.from_user.id,
        title=item[0],
        description=f"{item[3]} — 1 dona",
        payload=f"stars:{item_id}",
        currency="XTR",
        prices=[LabeledPrice(label=item[0], amount=stars)],
    )
    await callback.answer("To‘lov oynasi yuborildi")


@economy_router.pre_checkout_query()
async def stars_pre_checkout(pre_checkout_query: PreCheckoutQuery):
    await pre_checkout_query.answer(ok=True)


@economy_router.message(F.successful_payment)
async def stars_successful_payment(message: Message):
    payment = message.successful_payment
    payload = payment.invoice_payload or ""
    if not payload.startswith("stars:"):
        return
    item_id = payload.split(":", 1)[1]
    item = STORE_ITEMS.get(item_id)
    if item is None:
        return
    ensure_profile(message.from_user)
    with _connect() as connection:
        connection.execute(
            "INSERT INTO inventory(user_id, item_id, quantity) VALUES (?, ?, 1) "
            "ON CONFLICT(user_id, item_id) DO UPDATE SET quantity=quantity+1",
            (message.from_user.id, item_id),
        )
    await message.answer(f"✅ To‘lov qabul qilindi. Sizga {item[0]} 1 dona qo‘shildi.")
    buyer_name = esc(message.from_user.full_name or "Noma’lum")
    buyer_username = f"@{esc(message.from_user.username)}" if message.from_user.username else "username yo‘q"
    await message.bot.send_message(
        OWNER_ID,
        f"⭐ <b>Yangi Stars xaridi</b>\n\n"
        f"👤 {buyer_name} — {buyer_username}\n"
        f"🆔 UID: <code>{message.from_user.id}</code>\n"
        f"🛍 Buyum: {item[0]}\n"
        f"⭐ To‘lov: <b>{payment.total_amount}</b> Stars\n\n"
        "Stars botning Telegram balansiga tushdi.",
    )


@economy_router.message(Command("profil", "profile", "balance"))
async def profile_command(message: Message):
    import keyboards as kb
    profile = ensure_profile(message.from_user)
    # Birinchi rasmdagi kabi: profil ma’lumoti yuqorida, xizmatlar menyusi pastda.
    await message.answer(profile_text(profile), reply_markup=kb.profile_menu_keyboard)


def profile_swap_menu_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔄 UID orqali profil almashtirish", callback_data="profile_swap:start")]
    ])


async def _start_profile_swap(message: Message, user=None):
    user = user or message.from_user
    ensure_profile(user)
    with _connect() as connection:
        item = connection.execute("SELECT quantity FROM inventory WHERE user_id=? AND item_id='profil_almashish' AND quantity>0", (user.id,)).fetchone()
        if not item:
            await message.answer("🔄 Profil almashtirish buyumi yo‘q. Avval Do‘kondan sotib oling.")
            return
        connection.execute("INSERT INTO profile_swap_sessions(user_id, active, created_at) VALUES (?, 1, ?) ON CONFLICT(user_id) DO UPDATE SET active=1, created_at=excluded.created_at", (user.id, datetime.utcnow().isoformat()))
    await message.answer("🔄 <b>Profil almashtirish</b>\n\nAlmashtirmoqchi bo‘lgan o‘yinchining profilida turgan <b>UID</b> raqamini shu chatga yuboring.\n\nMasalan: <code>/profil_almashtir 123456789</code>")


@economy_router.callback_query(F.data == "profile_swap:start")
async def profile_swap_start_callback(callback: CallbackQuery):
    await _start_profile_swap(callback.message, callback.from_user)
    await callback.answer()


async def _handle_profile_swap_uid(message: Message, target_id: int):
    requester_id = message.from_user.id
    if target_id == requester_id:
        await message.answer("O‘zingiz bilan profil almashtira olmaysiz.")
        return
    ensure_profile(message.from_user)
    with _connect() as connection:
        item = connection.execute("SELECT quantity FROM inventory WHERE user_id=? AND item_id='profil_almashish' AND quantity>0", (requester_id,)).fetchone()
        session = connection.execute("SELECT active FROM profile_swap_sessions WHERE user_id=?", (requester_id,)).fetchone()
        if not item:
            await message.answer("🔄 Profil almashtirish buyumi yo‘q. Avval Do‘kondan sotib oling.")
            return
        if session is not None and session["active"] == 0 and message.text and not message.text.startswith("/"):
            await message.answer("Avval profil almashtirish menyusidan UID kiritishni boshlang.")
            return
        target = connection.execute("SELECT * FROM profiles WHERE user_id=?", (target_id,)).fetchone()
        if target is None:
            await message.answer("Bu UID egasi botda ro‘yxatdan o‘tmagan. UIDni profilidan qayta tekshiring.")
            return
        pending = connection.execute("SELECT request_id FROM profile_swap_requests WHERE requester_id=? AND target_id=? AND status='pending'", (requester_id, target_id)).fetchone()
        if pending:
            await message.answer("⏳ Bu foydalanuvchiga allaqachon so‘rov yuborilgan.")
            return
        changed = connection.execute("UPDATE inventory SET quantity=quantity-1 WHERE user_id=? AND item_id='profil_almashish' AND quantity>0", (requester_id,))
        if changed.rowcount != 1:
            await message.answer("Profil almashtirish buyumi topilmadi yoki allaqachon ishlatilgan.")
            return
        connection.execute("UPDATE profile_swap_sessions SET active=0 WHERE user_id=?", (requester_id,))
        cursor = connection.execute("INSERT INTO profile_swap_requests(requester_id, target_id, created_at) VALUES (?, ?, ?)", (requester_id, target_id, datetime.utcnow().isoformat()))
        request_id = cursor.lastrowid
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ Qabul qilish", callback_data=f"profile_swap:accept:{request_id}"), InlineKeyboardButton(text="❌ Rad etish", callback_data=f"profile_swap:reject:{request_id}")]
    ])
    await message.answer(f"🔄 <b>{esc(target['full_name'] or target['username'] or str(target_id))}</b> ga profil almashtirish so‘rovi yuborildi.")
    try:
        await message.bot.send_message(target_id, f"🔄 <b>{esc(message.from_user.full_name)}</b> siz bilan profil almashmoqchi.\nProfil va balans ma’lumotlarini almashtirishga rozimisiz?", reply_markup=keyboard)
    except Exception:
        with _connect() as connection:
            connection.execute("UPDATE profile_swap_requests SET status='failed' WHERE request_id=?", (request_id,))
            connection.execute("INSERT INTO inventory(user_id, item_id, quantity) VALUES (?, 'profil_almashish', 1) ON CONFLICT(user_id, item_id) DO UPDATE SET quantity=quantity+1", (requester_id,))
        await message.answer("❌ Bu foydalanuvchiga shaxsiy xabar yuborib bo‘lmadi. U avval botga /start yozsin.")


@economy_router.message(Command("profil_almashtir", "profile_swap"))
async def profile_swap_command(message: Message):
    parts = message.text.split(maxsplit=1) if message.text else []
    if len(parts) != 2 or not parts[1].strip().isdigit():
        await _start_profile_swap(message)
        return
    await _handle_profile_swap_uid(message, int(parts[1].strip()))


@economy_router.message(F.text.regexp(r"^\s*\d+\s*$"))
async def profile_swap_plain_uid(message: Message):
    with _connect() as connection:
        session = connection.execute("SELECT active FROM profile_swap_sessions WHERE user_id=?", (message.from_user.id,)).fetchone()
    if not session or not session["active"]:
        return
    await _handle_profile_swap_uid(message, int(message.text.strip()))


@economy_router.callback_query(F.data.startswith("profile_swap:"))
async def profile_swap_callback(callback: CallbackQuery):
    _, decision, request_id_raw = callback.data.split(":")
    request_id = int(request_id_raw)
    with _connect() as connection:
        request = connection.execute("SELECT * FROM profile_swap_requests WHERE request_id=? AND target_id=? AND status='pending'", (request_id, callback.from_user.id)).fetchone()
        if request is None:
            await callback.answer("Bu so‘rov eskirgan yoki sizga tegishli emas.", show_alert=True)
            return
        if decision == "reject":
            connection.execute("UPDATE profile_swap_requests SET status='rejected' WHERE request_id=?", (request_id,))
            await callback.message.edit_text("❌ Profil almashtirish so‘rovi rad etildi.")
            await callback.answer("So‘rov rad etildi.")
            return
        requester = connection.execute("SELECT * FROM profiles WHERE user_id=?", (request["requester_id"],)).fetchone()
        target = connection.execute("SELECT * FROM profiles WHERE user_id=?", (request["target_id"],)).fetchone()
        if requester is None or target is None:
            connection.execute("UPDATE profile_swap_requests SET status='failed' WHERE request_id=?", (request_id,))
            await callback.message.edit_text("❌ So‘rov bajarilmadi: profil topilmadi.")
            await callback.answer("Profil topilmadi.", show_alert=True)
            return
        fields = ("money", "diamonds", "coins", "pro_until", "vip_until", "games", "wins")
        requester_values = [requester[field] for field in fields]
        target_values = [target[field] for field in fields]
        connection.execute("UPDATE profiles SET money=?, diamonds=?, coins=?, pro_until=?, vip_until=?, games=?, wins=? WHERE user_id=?", (*target_values, requester["user_id"]))
        connection.execute("UPDATE profiles SET money=?, diamonds=?, coins=?, pro_until=?, vip_until=?, games=?, wins=? WHERE user_id=?", (*requester_values, target["user_id"]))
        connection.execute("UPDATE profile_swap_requests SET status='accepted' WHERE request_id=?", (request_id,))
    await callback.message.edit_text("✅ Profil almashtirish qabul qilindi. Profillar almashdi.")
    await callback.answer("Profil almashdi.", show_alert=True)
    try:
        await callback.bot.send_message(request["requester_id"], "✅ Profil almashtirish qabul qilindi. Balans va status profillari almashdi.")
    except Exception:
        pass




GIFT_SUBSCRIPTION_CHAT = os.getenv("GIFT_SUBSCRIPTION_CHAT", "@BotSaleUz").strip()
GIFT_SUBSCRIPTION_URL = os.getenv("GIFT_SUBSCRIPTION_URL", "https://t.me/BotSaleUz").strip()


def promo_text() -> str:
    return ("🎁 <b>GURUH SOVG‘ASI</b>\n\n"
            f"Sovg‘ani olish uchun avval {GIFT_SUBSCRIPTION_CHAT} kanaliga obuna bo‘ling.\n"
            "💎 <b>200 almaz</b>  •  💵 <b>2000 dollar</b>\n\n"
            "Sovg‘a obunachilarga faqat bir marta beriladi.")


def promo_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📢 Kanalga obuna bo‘lish", url=GIFT_SUBSCRIPTION_URL)],
        [InlineKeyboardButton(text="✅ Obunani tekshirish va sovg‘ani olish", callback_data="promo:check", style="success")],
        [InlineKeyboardButton(text="⬅️ Orqaga", callback_data="menu_back")],
    ])


@economy_router.callback_query(F.data == "promo:2x")
async def promo_open_callback(callback: CallbackQuery):
    await callback.message.edit_text(promo_text(), reply_markup=promo_keyboard())
    await callback.answer()


@economy_router.callback_query(F.data == "promo:check")
async def promo_check_callback(callback: CallbackQuery, bot: Bot):
    user_id = callback.from_user.id
    try:
        member = await bot.get_chat_member(chat_id=GIFT_SUBSCRIPTION_CHAT, user_id=user_id)
    except Exception:
        await callback.answer("Kanal tekshiruvi ishlamadi. Bot kanalga administrator bo‘lishi kerak.", show_alert=True)
        return
    status = getattr(member, "status", "")
    is_subscribed = status in {"creator", "administrator", "member"} or (
        status == "restricted" and getattr(member, "is_member", False)
    )
    if not is_subscribed:
        await callback.answer("Avval kanalga obuna bo‘ling.", show_alert=True)
        return
    with _connect() as connection:
        connection.execute("BEGIN IMMEDIATE")
        if connection.execute("SELECT 1 FROM promo_claims WHERE user_id=?", (user_id,)).fetchone():
            await callback.answer("Guruh sovg‘asini siz avval olgansiz.", show_alert=True)
            return
        ensure_profile(callback.from_user)
        connection.execute(
            "UPDATE profiles SET money=MIN(?, money+2000), diamonds=MIN(?, diamonds+200) WHERE user_id=?",
            (MAX_INT64, MAX_INT64, user_id),
        )
        connection.execute(
            "INSERT INTO promo_claims(user_id, promo_code, claimed_at) VALUES (?, ?, ?)",
            (user_id, "group_gift", datetime.utcnow().isoformat()),
        )
        updated_profile = connection.execute("SELECT * FROM profiles WHERE user_id=?", (user_id,)).fetchone()
    await callback.message.edit_text(
        "✅ <b>Guruh sovg‘asi olindi!</b>\n\nSizga 💎 200 almaz va 💵 2000 dollar berildi.\n\n" + profile_text(updated_profile),
        reply_markup=__import__("keyboards").back_keyboard,
    )
    await callback.answer("Guruh sovg‘asi berildi!", show_alert=True)

@economy_router.message(Command("vip"))
async def vip_command(message: Message):
    profile = ensure_profile(message.from_user)
    now = datetime.utcnow()
    active = is_owner(message) or (profile["vip_until"] and datetime.fromisoformat(profile["vip_until"]) > now)
    await message.answer("👑 VIP status faol." if active else "VIP status faol emas. Do‘kondan VIP User sotib olishingiz mumkin.")


def award_game_rewards(participant_ids, winner_ids, rounds: int, award_key: str | None = None):
    """O‘yin yakunida ball va Dollar mukofotlarini alohida qayd qiladi."""
    rounds = max(1, int(rounds or 1))
    loser_points = -min(5, rounds)
    loser_dollars = min(5, rounds)
    rewarded = []
    now = datetime.utcnow().isoformat()
    with _connect() as connection:
        if award_key:
            inserted = connection.execute(
                "INSERT OR IGNORE INTO game_awards(award_key, awarded_at) VALUES (?, ?)", (award_key, now)
            ).rowcount
            if inserted == 0:
                return []
        for user_id in sorted(set(participant_ids)):
            profile = connection.execute("SELECT * FROM profiles WHERE user_id=?", (user_id,)).fetchone()
            if profile is None:
                continue
            won = user_id in winner_ids
            if won:
                pro_active = bool(profile["pro_until"] and datetime.fromisoformat(profile["pro_until"]) > datetime.utcnow())
                points = min(30 if pro_active else 15, max(1, rounds * (5 if pro_active else 3)))
                dollars = 20
                reason = "win"
            else:
                points = loser_points
                dollars = loser_dollars
                reason = "loss"
            connection.execute(
                "UPDATE profiles SET rating_points=rating_points+?, money=MIN(?, money+?), games=games+1, wins=wins+? WHERE user_id=?",
                (points, MAX_INT64, dollars, 1 if won else 0, user_id),
            )
            connection.execute(
                "INSERT INTO rating_events(user_id, points, created_at, reason) VALUES (?, ?, ?, ?)",
                (user_id, points, now, reason),
            )
            rewarded.append((user_id, points, dollars, won))
    return rewarded


def rating_leaderboard_text(days=None) -> str:
    if days is not None:
        since = (datetime.utcnow() - timedelta(days=days)).isoformat()
        title = {1: "1 kunlik", 7: "7 kunlik / haftalik", 30: "30 kunlik / oylik"}.get(days, f"oxirgi {days} kunlik")
        query = ("SELECT p.full_name, p.username, SUM(e.points) AS score "
                 "FROM profiles p JOIN rating_events e ON e.user_id=p.user_id "
                 "WHERE e.created_at>=? GROUP BY p.user_id "
                 "HAVING SUM(e.points) != 0 ORDER BY score DESC, p.user_id ASC LIMIT 10")
        params = (since,)
    else:
        title = "Umumiy"
        query = "SELECT full_name, username, rating_points AS score FROM profiles WHERE rating_points != 0 ORDER BY rating_points DESC, user_id ASC LIMIT 10"
        params = ()
    with _connect() as connection:
        rows = connection.execute(query, params).fetchall()
    if not rows:
        return f"🏆 <b>{title} Top reyting</b>\n\nHozircha ballar yo‘q."
    lines = [f"🏆 <b>{title} Top reyting</b>"]
    for index, row in enumerate(rows, 1):
        name = esc(row["full_name"] or row["username"] or "Noma’lum")
        lines.append(f"{index}. {name} — <b>{row['score']} ball</b>")
    return "\n".join(lines)


@economy_router.message(Command("top", "reyting", "leaderboard"))
async def leaderboard_command(message: Message):
    parts = (message.text or "").split()
    days = None
    if len(parts) > 1:
        try:
            days = int(parts[1])
        except ValueError:
            await message.answer("Foydalanish: /top, /top 1, /top 7 yoki /top 30")
            return
        if days not in {1, 7, 30}:
            await message.answer("Faqat /top 1, /top 7 yoki /top 30 ishlatiladi.")
            return
    await message.answer(rating_leaderboard_text(days))


def wealth_leaderboard_text(limit: int = 10, include_coins: bool = True) -> str:
    sections = []
    with _connect() as connection:
        columns = [("money", "Dollar bo‘yicha Top o‘yinchilar", "💵"), ("diamonds", "Almaz bo‘yicha Top o‘yinchilar", "💎")]
        if include_coins:
            columns.append(("coins", "Coin bo‘yicha Top o‘yinchilar", "🪙"))
        for column, title, emoji in columns:
            rows = connection.execute(
                f"SELECT full_name, username, {column} AS balance FROM profiles ORDER BY {column} DESC, user_id ASC LIMIT ?",
                (limit,),
            ).fetchall()
            lines = [f"<b>{emoji} {title} — Top {limit}</b>"]
            for index, row in enumerate(rows, 1):
                name = esc(row["full_name"] or row["username"] or "Noma’lum")
                lines.append(f"{index}. {name} — <b>{number(row['balance'])}</b>")
            sections.append("\n".join(lines))
    return f"🏅 <b>TOP {limit} O‘YINCHILAR</b>\n\n" + "\n\n".join(sections)


def wealth_menu_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🏆 Top 10 — pul, almaz, coin", callback_data="wealth:10", style="primary")],
        [InlineKeyboardButton(text="💰 Top 30 — eng boylar", callback_data="wealth:30", style="danger")],
        [InlineKeyboardButton(text="⬅️ Orqaga", callback_data="menu_back", style="primary")],
    ])


@economy_router.callback_query(F.data == "menu_top_players")
async def top_players_callback(callback: CallbackQuery):
    await callback.message.edit_text(
        "🏅 <b>TOP O‘YINCHILAR</b>\n\nQaysi reytingni ko‘rmoqchisiz?",
        reply_markup=wealth_menu_keyboard(),
    )
    await callback.answer()


@economy_router.callback_query(F.data == "wealth:10")
async def wealth_top10_callback(callback: CallbackQuery):
    await callback.message.edit_text(wealth_leaderboard_text(10, True), reply_markup=wealth_menu_keyboard())
    await callback.answer()


@economy_router.callback_query(F.data == "wealth:30")
async def wealth_top30_callback(callback: CallbackQuery):
    await callback.message.edit_text(wealth_leaderboard_text(30, False), reply_markup=wealth_menu_keyboard())
    await callback.answer()


@economy_router.message(Command("topplayers", "topboylar"))
async def top_players_command(message: Message):
    await message.answer(
        "🏅 <b>TOP O‘YINCHILAR</b>\n\nQaysi reytingni ko‘rmoqchisiz?",
        reply_markup=wealth_menu_keyboard(),
    )


@economy_router.message(Command("gift", "sovga"))
async def gift_command(message: Message):
    parts = message.text.split() if message.text else []
    if len(parts) != 3:
        await message.answer("Foydalanish: /gift @username coin_miqdori")
        return
    try:
        amount = int(parts[2])
    except ValueError:
        await message.answer("Coin miqdori son bo‘lishi kerak.")
        return
    if amount <= 0:
        await message.answer("Miqdor 0 dan katta bo‘lishi kerak.")
        return
    ensure_profile(message.from_user)
    with _connect() as connection:
        target = find_user(connection, parts[1])
        sender = connection.execute("SELECT * FROM profiles WHERE user_id=?", (message.from_user.id,)).fetchone()
        if target is None:
            await message.answer("Qabul qiluvchi botda /start qilmagan yoki username topilmadi.")
            return
        if target["user_id"] == message.from_user.id:
            await message.answer("O‘zingizga gift yubora olmaysiz.")
            return
        if sender["coins"] < amount:
            await message.answer("Gift uchun coin yetarli emas.")
            return
        connection.execute("UPDATE profiles SET coins=coins-? WHERE user_id=?", (amount, message.from_user.id))
        connection.execute("UPDATE profiles SET coins=coins+? WHERE user_id=?", (amount, target["user_id"]))
    await message.answer(
        f"🎁 <b>{_user_handle(message.from_user)}</b> → <b>{_user_handle(None, target['full_name'], target['username'])}</b>\n"
        f"🪙 <b>{number(amount)}</b> coin yuborildi."
    )


def _user_handle(user, full_name=None, username=None) -> str:
    username = username if username is not None else getattr(user, "username", None)
    name = full_name if full_name is not None else getattr(user, "full_name", None)
    return f"@{esc(username)}" if username else esc(name or "Foydalanuvchi")


async def transfer_currency_by_reply(message: Message, kind: str):
    try:
        await message.delete()
    except Exception:
        pass
    if not message.reply_to_message or not message.reply_to_message.from_user:
        await message.answer("Bu buyruqni yuborish uchun foydalanuvchining xabariga reply qiling.")
        return
    parts = message.text.split() if message.text else []
    if len(parts) != 2:
        examples = {"money": "/money 100", "diamonds": "/give 10", "coins": "/gold 50"}
        await message.answer(f"Foydalanish: <code>{examples[kind]}</code>")
        return
    try:
        amount = int(parts[1])
        if amount <= 0 or amount > MAX_INT64:
            raise ValueError
    except ValueError:
        await message.answer("Miqdor 1 dan 9 223 372 036 854 775 807 gacha bo‘lishi kerak.")
        return
    sender = ensure_profile(message.from_user)
    recipient_user = message.reply_to_message.from_user
    recipient = ensure_profile(recipient_user)
    if sender["user_id"] == recipient["user_id"]:
        await message.answer("O‘zingizga valyuta yubora olmaysiz.")
        return
    labels = {"money": "dollar", "diamonds": "almaz", "coins": "coin"}
    column = kind
    owner_sender = sender["user_id"] == OWNER_ID
    with _connect() as connection:
        sender_row = connection.execute("SELECT * FROM profiles WHERE user_id=?", (sender["user_id"],)).fetchone()
        recipient_row = connection.execute("SELECT * FROM profiles WHERE user_id=?", (recipient["user_id"],)).fetchone()
        if not owner_sender and sender_row[column] < amount:
            await message.answer(f"Sizda yetarli {labels[kind]} yo‘q.")
            return
        if recipient_row[column] > MAX_INT64 - amount:
            await message.answer(f"Qabul qiluvchining {labels[kind]} balansi maksimal chegaraga yetadi.")
            return
        if not owner_sender:
            connection.execute(f"UPDATE profiles SET {column}={column}-? WHERE user_id=?", (amount, sender["user_id"]))
        connection.execute(f"UPDATE profiles SET {column}={column}+? WHERE user_id=?", (amount, recipient["user_id"]))
    badges = {"money": "💵", "diamonds": "💎", "coins": "🪙"}
    await message.answer(
        f"✅ <b>{_user_handle(message.from_user)}</b> → <b>{_user_handle(recipient_user)}</b>\n"
        f"{badges[kind]} <b>{number(amount)}</b> {labels[kind]} yuborildi."
    )


# Bu buyruqlar Telegram Menu ro‘yxatiga qo‘shilmaydi; faqat reply qilib yozilganda ishlaydi.
@economy_router.message(Command("money"))
async def money_transfer_command(message: Message):
    await transfer_currency_by_reply(message, "money")


@economy_router.message(Command("give"))
async def diamond_transfer_command(message: Message):
    await transfer_currency_by_reply(message, "diamonds")


@economy_router.message(Command("gold"))
async def coin_transfer_command(message: Message):
    await transfer_currency_by_reply(message, "coins")


@economy_router.message(Command("pro"))
async def pro_command(message: Message):
    await show_pro_menu(message)


async def show_pro_menu(target):
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="15 kun — 70 💎", callback_data="pro:15:diamonds:70", style="primary")],
        [InlineKeyboardButton(text="30 kun — 100 💎", callback_data="pro:30:diamonds:100", style="success")],
        [InlineKeyboardButton(text="⬅️ Orqaga", callback_data="shop:back", style="primary")],
    ])
    text = ("⭐ <b>PRO AKKAUNT</b>\n\nPRO sizga maxsus belgi, nickname, guruhda xabar yozish, /leave, chiroyli profil va reyting belgisini beradi.\n\n🛒 Sotib olish usulini tanlang:")
    if isinstance(target, Message):
        await target.answer(text, reply_markup=keyboard)
    else:
        await target.message.edit_text(text, reply_markup=keyboard)


@economy_router.callback_query(F.data == "pro:menu")
async def pro_menu_callback(callback: CallbackQuery):
    await show_pro_menu(callback)
    await callback.answer()


@economy_router.callback_query(F.data.startswith("pro:"))
async def pro_buy_callback(callback: CallbackQuery):
    _, days_raw, currency, price_raw = callback.data.split(":")
    days, price = int(days_raw), int(price_raw)
    ensure_profile(callback.from_user)
    with _connect() as connection:
        profile = connection.execute("SELECT * FROM profiles WHERE user_id=?", (callback.from_user.id,)).fetchone()
        if profile["pro_until"] and datetime.fromisoformat(profile["pro_until"]) > datetime.utcnow():
            await callback.answer("✅ Sizda PRO allaqachon faol. Qayta sotib olib bo‘lmaydi.", show_alert=True)
            return
        if profile[currency] < price:
            await callback.answer("Mablag‘ yetarli emas.", show_alert=True)
            return
        current = datetime.utcnow()
        until = max(current, datetime.utcnow()) + timedelta(days=days)
        connection.execute(f"UPDATE profiles SET {currency}=?, pro_until=? WHERE user_id=?", (profile[currency] - price, until.isoformat(), callback.from_user.id))
    await callback.answer(f"PRO {days} kunga faollashtirildi.", show_alert=True)
    await callback.message.edit_text(f"✅ PRO faollashtirildi. Tugash sanasi: {until.strftime('%Y-%m-%d')}")


@economy_router.message(Command("geroy", "hero"))
async def hero_command(message: Message):
    hero = ensure_hero(message.from_user)
    if not hero["owned"]:
        await message.answer("🕶 <b>Geroy</b>\n\n❌ Sizda hozircha geroy yo‘q.\n\nGeroy sotib olingandan keyin daraja, kuch, himoya va hujum imkoniyatlari ochiladi.\n\nNarxi: <b>200 💎</b>", reply_markup=hero_buy_keyboard())
        return
    await message.answer(hero_text(hero), reply_markup=hero_keyboard())


@economy_router.callback_query(F.data == "hero:buy")
async def hero_buy(callback: CallbackQuery):
    ensure_hero(callback.from_user)
    user_id = callback.from_user.id
    with _connect() as connection:
        # Bir vaqtning o‘zida kelgan ikki marta bosishda ham ikkinchi xarid o‘tmasligi uchun
        # butun tekshiruv va yangilash bitta tranzaksiyada bajariladi.
        connection.execute("BEGIN IMMEDIATE")
        profile = connection.execute("SELECT * FROM profiles WHERE user_id=?", (user_id,)).fetchone()
        hero = connection.execute("SELECT * FROM heroes WHERE user_id=?", (user_id,)).fetchone()
        if hero["owned"]:
            await callback.answer("Sizda allaqachon geroy bor. Qayta sotib olib bo‘lmaydi.", show_alert=True)
            return
        if profile["diamonds"] < 200:
            await callback.answer("Geroy sotib olish uchun 200 almaz kerak.", show_alert=True)
            return
        changed = connection.execute("UPDATE heroes SET owned=1 WHERE user_id=? AND owned=0", (user_id,))
        if changed.rowcount != 1:
            await callback.answer("Sizda allaqachon geroy bor. Qayta sotib olib bo‘lmaydi.", show_alert=True)
            return
        power = (100 + 29) // 30
        connection.execute("UPDATE profiles SET diamonds=diamonds-200 WHERE user_id=?", (user_id,))
        connection.execute("UPDATE heroes SET power_min=?, power_max=?, max_defense=?, defense=? WHERE user_id=?", (power, power, power, power, user_id))
        hero = connection.execute("SELECT * FROM heroes WHERE user_id=?", (user_id,)).fetchone()
    await callback.message.edit_text(hero_text(hero), reply_markup=hero_keyboard())
    await callback.answer("Geroy sotib olindi. Uni qayta sotib olib bo‘lmaydi.", show_alert=True)


@economy_router.callback_query(F.data == "hero:levels")
async def hero_levels(callback: CallbackQuery):
    await callback.message.edit_text("⭐ Daraja oshgani sari geroyning kuchi va himoyasi oshadi. Ovoz berishdan oldin geroy hujum yoki himoya qilishi mumkin.", reply_markup=hero_keyboard())
    await callback.answer()


@economy_router.callback_query(F.data == "hero:points")
async def hero_points(callback: CallbackQuery):
    ensure_hero(callback.from_user)
    with _connect() as connection:
        profile = connection.execute("SELECT * FROM profiles WHERE user_id=?", (callback.from_user.id,)).fetchone()
        if hero := connection.execute("SELECT * FROM heroes WHERE user_id=?", (callback.from_user.id,)).fetchone():
            if not hero["owned"]:
                await callback.answer("Avval geroy sotib oling.", show_alert=True)
                return
            if hero["level"] >= 30:
                await callback.answer("Geroyingiz maksimal 30-darajaga yetgan.", show_alert=True)
                return
        level = hero["level"]
        price = 100 + ((level - 1) // 2) * 15
        if profile["diamonds"] < price:
            await callback.answer(f"Bu darajani oshirish uchun {price} almaz kerak.", show_alert=True)
            return
        connection.execute("UPDATE profiles SET diamonds=diamonds-? WHERE user_id=?", (price, callback.from_user.id))
        level += 1
        power = min(100, (level * 100 + 29) // 30)
        connection.execute("UPDATE heroes SET level=?, power_min=?, power_max=?, max_defense=?, defense=? WHERE user_id=?", (level, power, power, power, power, callback.from_user.id))
        hero = connection.execute("SELECT * FROM heroes WHERE user_id=?", (callback.from_user.id,)).fetchone()
    await callback.message.edit_text(hero_text(hero), reply_markup=hero_keyboard())
    await callback.answer(f"Geroy {level}-darajaga kuchaytirildi.", show_alert=True)


@economy_router.callback_query(F.data == "hero:defense")
async def hero_defense(callback: CallbackQuery):
    ensure_hero(callback.from_user)
    with _connect() as connection:
        profile = connection.execute("SELECT * FROM profiles WHERE user_id=?", (callback.from_user.id,)).fetchone()
        hero = connection.execute("SELECT * FROM heroes WHERE user_id=?", (callback.from_user.id,)).fetchone()
        if not hero["owned"]:
            await callback.answer("Avval geroy sotib oling.", show_alert=True)
            return
        if hero["max_defense"] >= 50:
            await callback.answer("Geroy himoyasi maksimal 50% ga yetgan.", show_alert=True)
            return
        if profile["money"] < 164:
            await callback.answer("164 dollar kerak.", show_alert=True)
            return
        connection.execute("UPDATE profiles SET money=money-164 WHERE user_id=?", (callback.from_user.id,))
        connection.execute("UPDATE heroes SET max_defense=MIN(50, max_defense+10), defense=MIN(50, max_defense+10) WHERE user_id=?", (callback.from_user.id,))
        hero = connection.execute("SELECT * FROM heroes WHERE user_id=?", (callback.from_user.id,)).fetchone()
    await callback.message.edit_text(hero_text(hero), reply_markup=hero_keyboard())
    await callback.answer("Himoya yangilandi.", show_alert=True)


@economy_router.callback_query(F.data == "hero:charge")
async def hero_charge(callback: CallbackQuery):
    ensure_hero(callback.from_user)
    with _connect() as connection:
        profile = connection.execute("SELECT * FROM profiles WHERE user_id=?", (callback.from_user.id,)).fetchone()
        hero = connection.execute("SELECT * FROM heroes WHERE user_id=?", (callback.from_user.id,)).fetchone()
        if not hero["owned"]:
            await callback.answer("Avval geroy sotib oling.", show_alert=True)
            return
        if profile["money"] < 195:
            await callback.answer("195 dollar kerak.", show_alert=True)
            return
        connection.execute("UPDATE profiles SET money=money-195 WHERE user_id=?", (callback.from_user.id,))
        connection.execute("UPDATE heroes SET charges=charges+10 WHERE user_id=?", (callback.from_user.id,))
        hero = connection.execute("SELECT * FROM heroes WHERE user_id=?", (callback.from_user.id,)).fetchone()
    await callback.message.edit_text(hero_text(hero), reply_markup=hero_keyboard())
    await callback.answer("Qurol zaryadlandi.", show_alert=True)


@economy_router.callback_query(F.data == "hero:rename")
async def hero_rename_help(callback: CallbackQuery):
    await callback.answer("Yangi nomni /geroy_nomi YANGI_NOM ko‘rinishida yuboring.", show_alert=True)


@economy_router.message(Command("geroy_nomi", "hero_name"))
async def hero_rename(message: Message):
    parts = message.text.split(maxsplit=1) if message.text else []
    if len(parts) != 2:
        await message.answer("Foydalanish: /geroy_nomi Yangi Nom")
        return
    ensure_hero(message.from_user)
    with _connect() as connection:
        profile = connection.execute("SELECT * FROM profiles WHERE user_id=?", (message.from_user.id,)).fetchone()
        if profile["money"] < 780:
            await message.answer("Geroy nomini o‘zgartirish uchun 780 dollar kerak.")
            return
        connection.execute("UPDATE profiles SET money=money-780 WHERE user_id=?", (message.from_user.id,))
        connection.execute("UPDATE heroes SET name=? WHERE user_id=?", (parts[1][:32], message.from_user.id))
    await message.answer("✅ Geroy nomi o‘zgartirildi. /geroy")


def replied_user(message: Message):
    if not message.reply_to_message or not message.reply_to_message.from_user:
        return None
    target = message.reply_to_message.from_user
    if target.is_bot:
        return None
    return target


def couple_row(connection, user_id: int):
    return connection.execute("SELECT * FROM couples WHERE user1_id=? OR user2_id=?", (user_id, user_id)).fetchone()


def partner_id(row, user_id: int):
    return row["user2_id"] if row["user1_id"] == user_id else row["user1_id"]


@economy_router.message(Command("para", "pair"))
async def pair_command(message: Message):
    try:
        await message.delete()
    except Exception:
        pass
    target = replied_user(message)
    if target is None:
        await message.answer("💞 Para qilish uchun odamning xabariga reply qilib /para yozing.")
        return
    if target.id == message.from_user.id:
        await message.answer("O‘zingiz bilan para bo‘la olmaysiz.")
        return
    ensure_profile(message.from_user)
    ensure_profile(target)
    now = datetime.utcnow().isoformat()
    with _connect() as connection:
        if couple_row(connection, message.from_user.id) or couple_row(connection, target.id):
            await message.answer("❌ Sizlardan biri allaqachon para bo‘lgan.")
            return
        existing = connection.execute("SELECT request_id FROM pair_requests WHERE requester_id=? AND target_id=? AND status='pending'", (message.from_user.id, target.id)).fetchone()
        if existing:
            await message.answer("⏳ Bu foydalanuvchiga allaqachon para so‘rovi yuborilgan.")
            return
        cursor = connection.execute("INSERT INTO pair_requests(requester_id, target_id, chat_id, message_id, created_at) VALUES (?, ?, ?, ?, ?)", (message.from_user.id, target.id, message.chat.id, None, now))
        request_id = cursor.lastrowid
        keyboard = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="✅ Qabul qilish", callback_data=f"pair:accept:{request_id}"), InlineKeyboardButton(text="❌ Rad etish", callback_data=f"pair:reject:{request_id}")]])
        sent = await message.answer(f"💞 <b>{esc(message.from_user.full_name)}</b> siz bilan para bo‘lishni xohlayapti, <b>{esc(target.full_name)}</b>!\n\nFaqat sizning tugmangiz ishlaydi.", reply_markup=keyboard)
        connection.execute("UPDATE pair_requests SET message_id=? WHERE request_id=?", (sent.message_id, request_id))


@economy_router.callback_query(F.data.startswith("pair:"))
async def pair_request_callback(callback: CallbackQuery):
    _, action, request_id_raw = callback.data.split(":")
    request_id = int(request_id_raw)
    with _connect() as connection:
        request = connection.execute("SELECT * FROM pair_requests WHERE request_id=?", (request_id,)).fetchone()
        if request is None or request["status"] != "pending":
            await callback.answer("Bu so‘rov endi faol emas.", show_alert=True)
            return
        if callback.from_user.id != request["target_id"]:
            await callback.answer("Bu tugma faqat so‘rov yuborilgan odam uchun.", show_alert=True)
            return
        if action == "reject":
            connection.execute("UPDATE pair_requests SET status='rejected' WHERE request_id=?", (request_id,))
            await callback.message.edit_text("❌ Para so‘rovi rad etildi.")
            await callback.answer("So‘rov rad etildi.")
            return
        if couple_row(connection, request["requester_id"]) or couple_row(connection, request["target_id"]):
            connection.execute("UPDATE pair_requests SET status='rejected' WHERE request_id=?", (request_id,))
            await callback.answer("Sizlardan biri allaqachon para bo‘lgan.", show_alert=True)
            return
        first, second = sorted((request["requester_id"], request["target_id"]))
        connection.execute("INSERT INTO couples(user1_id, user2_id, created_at) VALUES (?, ?, ?)", (first, second, datetime.utcnow().isoformat()))
        connection.execute("UPDATE pair_requests SET status='accepted' WHERE request_id=?", (request_id,))
    await callback.message.edit_text("💞 Para bo‘ldingizlar! Juftlikni buzish uchun guruhda oddiy /dpara yozing.")
    await callback.answer("Para qabul qilindi!")


def account_card(profile):
    username = f"@{esc(profile['username'])}" if profile["username"] else "username yo‘q"
    mention = f'<a href="tg://user?id={profile["user_id"]}">{esc(profile["full_name"])}</a>'
    return f"👤 {mention}\n📎 Username: {username}"


@economy_router.message(Command("mypara", "meningpara", "mpara"))
async def mypara_command(message: Message):
    ensure_profile(message.from_user)
    with _connect() as connection:
        row = couple_row(connection, message.from_user.id)
        if row is None:
            await message.answer("💔 Siz hozircha hech kim bilan haqiqiy juftlik emassiz.")
            return
        other_id = partner_id(row, message.from_user.id)
        me = connection.execute("SELECT * FROM profiles WHERE user_id=?", (message.from_user.id,)).fetchone()
        other = connection.execute("SELECT * FROM profiles WHERE user_id=?", (other_id,)).fetchone()
    await message.answer(
        "💞 <b>Haqiqiy juftlik</b>\n\n"
        "Siz quyidagi foydalanuvchi bilan para bo‘lgansiz:\n\n"
        f"{account_card(me)}\n\n❤️ + ❤️\n\n{account_card(other)}"
    )


@economy_router.message(Command("dpara", "unpair"))
async def unpair_command(message: Message):
    try:
        await message.delete()
    except Exception:
        pass
    with _connect() as connection:
        row = couple_row(connection, message.from_user.id)
        if row is None:
            await message.answer("Siz hozir hech kim bilan para emassiz.")
            return
        target_id = partner_id(row, message.from_user.id)
        target = connection.execute("SELECT * FROM profiles WHERE user_id=?", (target_id,)).fetchone()
        first, second = sorted((message.from_user.id, target_id))
        connection.execute("DELETE FROM couples WHERE user1_id=? AND user2_id=?", (first, second))
    target_name = target["full_name"] if target else "partneringiz"
    await message.answer(f"💔 <b>{esc(message.from_user.full_name)}</b> va <b>{esc(target_name)}</b> endi para emas.")


@economy_router.message(Command("shop", "magazin", "dokon", "do'kon"))
async def shop_command(message: Message):
    await message.answer("🧑🏻‍💼 <b>Do‘kon</b>\nBuyumni tanlang:", reply_markup=shop_keyboard())


@economy_router.callback_query(F.data == "shop:chests")
async def chest_menu(callback: CallbackQuery):
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="💵 Super sandiq — 10 💎", callback_data="chest:super")],
        [InlineKeyboardButton(text="💎 Mega sandiq — 10 000 💵", callback_data="chest:mega")],
        [InlineKeyboardButton(text="⬅️ Orqaga", callback_data="shop:back")],
    ])
    await callback.message.edit_text(
        "🎁 <b>Sandiqlar haqida</b>\n\n💵 Super sandiq: 10 💎, ichidan 5 000–15 000 dollar.\n\n💎 Mega sandiq: 10 000 dollar, ichidan 1–10 almaz.\n\nHar bir sandiqni 1 oyda 1 marta ochish mumkin.",
        reply_markup=keyboard,
    )
    await callback.answer()


async def open_chest(callback: CallbackQuery, chest_id: str):
    ensure_profile(callback.from_user)
    price = 10 if chest_id == "super" else 10_000
    currency = "diamonds" if chest_id == "super" else "money"
    now = datetime.utcnow()
    with _connect() as connection:
        profile = connection.execute("SELECT * FROM profiles WHERE user_id=?", (callback.from_user.id,)).fetchone()
        opened = connection.execute("SELECT opened_at FROM chest_opens WHERE user_id=? AND chest_id=?", (callback.from_user.id, chest_id)).fetchone()
        pro_active = bool(profile["pro_until"] and datetime.fromisoformat(profile["pro_until"]) > now)
        if opened and not pro_active:
            last_open = datetime.fromisoformat(opened["opened_at"])
            if now - last_open < timedelta(days=30):
                days = 30 - (now - last_open).days
                await callback.answer(f"Bu sandiqni yana {days} kundan keyin ochasiz. PRO bilan cheklov yo‘q.", show_alert=True)
                return
        if profile[currency] < price:
            await callback.answer("Sandiqni ochish uchun mablag‘ yetarli emas.", show_alert=True)
            return
        if chest_id == "super":
            reward = random.randint(5_000, 15_000)
            connection.execute("UPDATE profiles SET diamonds=diamonds-?, money=min(9223372036854775807, money+?) WHERE user_id=?", (price, reward, callback.from_user.id))
            reward_text = f"{number(reward)} 💵 dollar"
        else:
            reward = random.randint(1, 10)
            connection.execute("UPDATE profiles SET money=money-?, diamonds=min(9223372036854775807, diamonds+?) WHERE user_id=?", (price, reward, callback.from_user.id))
            reward_text = f"{reward} 💎 almaz"
        connection.execute("INSERT INTO chest_opens(user_id, chest_id, opened_at) VALUES (?, ?, ?) ON CONFLICT(user_id, chest_id) DO UPDATE SET opened_at=excluded.opened_at", (callback.from_user.id, chest_id, now.isoformat()))
    await callback.answer(f"Sandiq ochildi: {reward_text} topdingiz!", show_alert=True)


@economy_router.callback_query(F.data == "chest:super")
async def super_chest_callback(callback: CallbackQuery):
    await open_chest(callback, "super")


@economy_router.callback_query(F.data == "chest:mega")
async def mega_chest_callback(callback: CallbackQuery):
    await open_chest(callback, "mega")


@economy_router.callback_query(F.data == "shop:exchange")
async def exchange_menu(callback: CallbackQuery):
    await callback.message.edit_text(
        "💱 <b>Valyuta almashtirish</b>\n\nKursni tanlang:",
        reply_markup=exchange_currency_keyboard(),
    )
    await callback.answer()


def exchange_currency_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="💎 1 Almaz → 500 Dollar", callback_data="exchange:d2m", style="primary")],
        [InlineKeyboardButton(text="💵 600 Dollar → 1 Almaz", callback_data="exchange:m2d", style="success")],
        [InlineKeyboardButton(text="⬅️ Orqaga", callback_data="shop:back", style="primary")],
    ])


@economy_router.callback_query(F.data == "shop:back")
async def shop_back(callback: CallbackQuery):
    import keyboards as kb
    profile = ensure_profile(callback.from_user)
    menu = kb.owner_admin_keyboard if callback.from_user.id == OWNER_ID else kb.profile_menu_keyboard
    await callback.message.edit_text(profile_text(profile), reply_markup=menu)
    await callback.answer()


@economy_router.callback_query(F.data.in_({"exchange:d2m", "exchange:m2d"}))
async def exchange_currency_callback(callback: CallbackQuery):
    ensure_profile(callback.from_user)
    direction = callback.data.split(":", 1)[1]
    with _connect() as connection:
        profile = connection.execute("SELECT * FROM profiles WHERE user_id=?", (callback.from_user.id,)).fetchone()
        if direction == "d2m":
            if profile["diamonds"] < 1:
                await callback.answer("Almaz yetarli emas.", show_alert=True)
                return
            connection.execute("UPDATE profiles SET diamonds=diamonds-1, money=money+500 WHERE user_id=?", (callback.from_user.id,))
            result = "1 almaz 500 dollarga almashtirildi."
        else:
            if profile["money"] < 600:
                await callback.answer("Dollar yetarli emas.", show_alert=True)
                return
            connection.execute("UPDATE profiles SET money=money-600, diamonds=diamonds+1 WHERE user_id=?", (callback.from_user.id,))
            result = "600 dollar 1 almazga almashtirildi."
    await callback.answer(result, show_alert=True)


@economy_router.callback_query(F.data.regexp(r"^exchange:\d+$"))
async def exchange_diamonds(callback: CallbackQuery):
    amount = int(callback.data.split(":")[1])
    ensure_profile(callback.from_user)
    with _connect() as connection:
        profile = connection.execute("SELECT * FROM profiles WHERE user_id=?", (callback.from_user.id,)).fetchone()
        if profile["diamonds"] < amount:
            await callback.answer("Almaz yetarli emas.", show_alert=True)
            return
        connection.execute("UPDATE profiles SET diamonds=diamonds-?, coins=coins+? WHERE user_id=?", (amount, amount // 2, callback.from_user.id))
    await callback.answer(f"{amount} almaz {amount // 2} coin’ga almashtirildi.", show_alert=True)


@economy_router.callback_query(F.data.startswith("buy:"))
async def buy_item(callback: CallbackQuery):
    item_id = callback.data.split(":", 1)[1]
    item = STORE_ITEMS[item_id]
    ensure_profile(callback.from_user)
    with _connect() as connection:
        profile = connection.execute("SELECT * FROM profiles WHERE user_id=?", (callback.from_user.id,)).fetchone()
        if profile[item[2]] < item[1]:
            await callback.answer("Mablag‘ yetarli emas.", show_alert=True)
            return
        connection.execute(f"UPDATE profiles SET {item[2]}={item[2]}-? WHERE user_id=?", (item[1], callback.from_user.id))
        if item_id == "vip_user":
            until = datetime.utcnow() + timedelta(days=30)
            connection.execute("UPDATE profiles SET vip_until=? WHERE user_id=?", (until.isoformat(), callback.from_user.id))
        connection.execute("INSERT INTO inventory(user_id, item_id, quantity) VALUES (?, ?, 1) ON CONFLICT(user_id, item_id) DO UPDATE SET quantity=quantity+1", (callback.from_user.id, item_id))
    await callback.answer(f"{item[0]} sotib olindi.", show_alert=True)
    if item_id == "profil_almashish":
        await callback.message.answer("✅ <b>Profil almashtirish buyumi sotib olindi.</b>\nEndi UID kiritish menyusini oching:", reply_markup=profile_swap_menu_keyboard())


@economy_router.message(Command("inventar", "inventory"))
async def inventory_command(message: Message):
    ensure_profile(message.from_user)
    with _connect() as connection:
        rows = connection.execute("SELECT item_id, quantity FROM inventory WHERE user_id=? AND quantity>0", (message.from_user.id,)).fetchall()
    if not rows:
        await message.answer("🎒 Inventaringiz bo‘sh. Do‘kon: /shop")
        return
    text = ["🎒 <b>Inventar</b>"]
    for row in rows:
        if row["item_id"] in STORE_ITEMS:
            text.append(f"{STORE_ITEMS[row['item_id']][0]}: <b>{row['quantity']} dona</b>")
    await message.answer("\n".join(text))


@economy_router.message(Command("sotib_ol", "buy"))
async def buy_text_command(message: Message):
    await message.answer("Do‘kondan buyum tanlash uchun /shop buyrug‘ini bosing.")


@economy_router.message(Command("sandiq", "chest"))
async def chest_text_command(message: Message):
    await message.answer("🎁 Sandiqlarni tanlash: /shop")


@economy_router.message(Command("almash", "exchange", "coin"))
async def exchange_text_command(message: Message):
    await exchange_menu_from_message(message)


async def exchange_menu_from_message(message: Message):
    await message.answer(
        "💱 <b>Valyuta almashtirish</b>\n\nKursni tanlang:",
        reply_markup=exchange_currency_keyboard(),
    )


@economy_router.message(Command("ber_pul", "give_money"))
async def give_money_command(message: Message):
    await grant_currency(message, "money")


@economy_router.message(Command("ber_almaz", "give_diamond", "give_diamonds"))
async def give_diamonds_command(message: Message):
    await grant_currency(message, "diamonds")


async def grant_currency(message: Message, kind: str):
    if not is_owner(message):
        await message.answer("⛔ Bu buyruq faqat bot egasi uchun.")
        return
    parts = message.text.split() if message.text else []
    if len(parts) != 3:
        await message.answer(f"Foydalanish: /{'ber_pul' if kind == 'money' else 'ber_almaz'} <user_id yoki @username> <miqdor>")
        return
    try:
        amount = int(parts[2])
        if amount <= 0 or amount > MAX_INT64:
            raise ValueError
    except ValueError:
        await message.answer("Miqdor 1 dan 9 223 372 036 854 775 807 gacha bo‘lishi kerak.")
        return
    with _connect() as connection:
        recipient = find_user(connection, parts[1])
        if recipient is None:
            await message.answer("Bu foydalanuvchi avval botga /start yuborsin.")
            return
        column = "money" if kind == "money" else "diamonds"
        new_balance = min(MAX_INT64, recipient[column] + amount)
        connection.execute(f"UPDATE profiles SET {column}=? WHERE user_id=?", (new_balance, recipient["user_id"]))
    await message.answer(f"✅ {esc(recipient['full_name'])} profiliga {number(amount)} {'dollar' if kind == 'money' else 'almaz'} berildi.")


@economy_router.message(Command("kurs"))
async def rate_command(message: Message):
    await message.answer("💱 Almaz kursi: 2 💎 = 1 🪙 coin.\nDo‘kon: /shop")


@economy_router.message(Command("iqtisod", "economy"))
async def economy_help(message: Message):
    await message.answer("💵 /profil\n🛍 /shop\n🎒 /inventar\n💎 /almash\n💱 /kurs\n👑 /vip")
