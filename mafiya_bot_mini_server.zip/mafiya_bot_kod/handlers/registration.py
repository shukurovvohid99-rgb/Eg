import json
import os
import random
import sqlite3
from pathlib import Path
from types import SimpleNamespace
from typing import List

from aiogram import Bot, F, Router
from aiogram.filters import BaseFilter, Command
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

import keyboards as kb
import texts
from callbacks import game_settings
from utils import esc, safe_send


active_users = []
live_players: list = []
# O‘yin boshlanganda barcha qatnashchilar shu snapshotda saqlanadi; active_users keyin tozalanadi.
game_participant_ids: set[int] = set()
# VS Game uchun har bir qatnashchining tanlagan jamoasi.
vs_mode = False
vs_teams: dict[int, str] = {}
game_chat_id = 0
registration_message_id = 0
play_writed = False
registration_start = False
game_start = False
GAME_STATE_PATH = Path(os.getenv("GAME_STATE_FILE", "mafia_game_state.json"))
ECONOMY_DB_PATH = Path(os.getenv("ECONOMY_DB", "economy.sqlite3"))
# Majburiy obuna manzili. Bo‘sh qiymat bilan tekshiruvni o‘chirish mumkin.
REQUIRED_SUBSCRIPTION_CHAT = os.getenv("REQUIRED_SUBSCRIPTION_CHAT", "@BotSaleUz").strip()
REQUIRED_SUBSCRIPTION_URL = os.getenv(
    "REQUIRED_SUBSCRIPTION_URL",
    "https://t.me/BotSaleUz",
).strip()


def subscription_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📢 Obuna bo‘lish", url=REQUIRED_SUBSCRIPTION_URL)],
        [InlineKeyboardButton(text="✅ Qayta tekshirish", callback_data="subscription:check")],
    ])


def _subscription_already_verified(user_id: int) -> bool:
    # Tasdiqlash doimiy saqlanadi: foydalanuvchi har safar qayta obuna
    # tekshiruviga tushmaydi.
    with sqlite3.connect(ECONOMY_DB_PATH) as connection:
        connection.execute(
            "CREATE TABLE IF NOT EXISTS required_subscription_verifications "
            "(user_id INTEGER PRIMARY KEY, verified_at TEXT NOT NULL)"
        )
        return connection.execute(
            "SELECT 1 FROM required_subscription_verifications WHERE user_id=?",
            (user_id,),
        ).fetchone() is not None


def _save_subscription_verification(user_id: int) -> None:
    with sqlite3.connect(ECONOMY_DB_PATH) as connection:
        connection.execute(
            "CREATE TABLE IF NOT EXISTS required_subscription_verifications "
            "(user_id INTEGER PRIMARY KEY, verified_at TEXT NOT NULL)"
        )
        connection.execute(
            "INSERT OR IGNORE INTO required_subscription_verifications(user_id, verified_at) "
            "VALUES (?, datetime('now'))",
            (user_id,),
        )


async def has_required_subscription(bot: Bot, user_id: int) -> bool:
    if not REQUIRED_SUBSCRIPTION_CHAT or _subscription_already_verified(user_id):
        return True
    try:
        member = await bot.get_chat_member(REQUIRED_SUBSCRIPTION_CHAT, user_id)
    except Exception:
        # Tekshiruv ishlamasa, foydalanuvchi tasdiqlangan deb belgilanmaydi.
        return False
    status = getattr(member, "status", "")
    is_member = status in {"creator", "administrator", "member"} or (
        status == "restricted" and getattr(member, "is_member", False)
    )
    if is_member:
        _save_subscription_verification(user_id)
    return is_member


async def require_subscription(message: Message, bot: Bot) -> bool:
    if await has_required_subscription(bot, message.from_user.id):
        return True
    await message.answer(
        "⛔ O‘yinda qatnashish uchun avval majburiy obunadan o‘ting.",
        reply_markup=subscription_keyboard(),
    )
    return False


def _consume_inventory_item(user_id: int, item_id: str) -> bool:
    with sqlite3.connect(ECONOMY_DB_PATH) as connection:
        row = connection.execute("SELECT quantity FROM inventory WHERE user_id=? AND item_id=?", (user_id, item_id)).fetchone()
        if not row or row[0] <= 0:
            return False
        connection.execute("UPDATE inventory SET quantity=quantity-1 WHERE user_id=? AND item_id=? AND quantity>0", (user_id, item_id))
        return True


class RegistrationFilter(BaseFilter):
    async def __call__(self, message: Message) -> bool:
        return not game_start


game_registration_router = Router(name="game_registration_router")
game_registration_router.message.filter(RegistrationFilter())


def reset_registration() -> None:
    global play_writed, registration_start, game_start, game_chat_id, registration_message_id, vs_mode
    active_users.clear()
    live_players.clear()
    game_participant_ids.clear()
    vs_teams.clear()
    vs_mode = False
    play_writed = False
    registration_start = False
    game_start = False
    game_chat_id = 0
    registration_message_id = 0
    game_settings.active_roles.clear()
    game_settings.count_roles = 0
    game_settings.count_mafies = 0
    game_settings.count_doctors = 0
    game_settings.count_sheriffs = 0
    _clear_game_state()


def _clear_game_state() -> None:
    try:
        GAME_STATE_PATH.unlink(missing_ok=True)
    except Exception:
        pass


def _save_game_state(status: str | None = None) -> None:
    if not game_chat_id or not (registration_start or game_start):
        _clear_game_state()
        return
    players = active_users if registration_start else live_players
    payload = {
        "chat_id": game_chat_id,
        "message_id": registration_message_id,
        "status": status or ("game" if game_start else "registration"),
        "participant_ids": sorted(game_participant_ids or {player.id for player in players}),
        "vs_mode": vs_mode,
        "vs_teams": {str(user_id): team for user_id, team in vs_teams.items()},
        "players": [
            {"id": player.id, "username": getattr(player, "username", None), "full_name": player.full_name,
             "role": player.__class__.__name__}
            for player in players
        ],
    }
    try:
        GAME_STATE_PATH.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass


def _restore_game_state(chat_id: int) -> bool:
    global game_chat_id, registration_message_id, registration_start, game_start, game_participant_ids, vs_mode, vs_teams
    try:
        payload = json.loads(GAME_STATE_PATH.read_text(encoding="utf-8"))
    except Exception:
        return False
    if payload.get("chat_id") != chat_id or payload.get("status") not in {"registration", "game"}:
        return False
    game_chat_id = chat_id
    registration_message_id = int(payload.get("message_id") or 0)
    users = [SimpleNamespace(id=item["id"], username=item.get("username"), full_name=item.get("full_name") or "Noma’lum") for item in payload.get("players", [])]
    game_participant_ids = {int(user_id) for user_id in payload.get("participant_ids", [])} or {user.id for user in users}
    vs_mode = bool(payload.get("vs_mode", False))
    vs_teams = {int(user_id): team for user_id, team in payload.get("vs_teams", {}).items() if team in {"red", "blue"}}
    if payload["status"] == "registration":
        active_users[:] = users
        live_players.clear()
        registration_start = True
        game_start = False
        return True
    from callbacks.game_process import Mafia, Don, Doctor, Player, Commissioner, Sergeant, Kezuvchi, Daydi, Sorcerer, Advocate, Killer, Wolf
    role_classes = {"Mafia": Mafia, "Don": Don, "Doctor": Doctor, "Player": Player, "Commissioner": Commissioner, "Sergeant": Sergeant, "Kezuvchi": Kezuvchi, "Daydi": Daydi, "Sorcerer": Sorcerer, "Advocate": Advocate, "Killer": Killer, "Wolf": Wolf}
    live_players[:] = [role_classes.get(item.get("role"), Player)(user) for item, user in zip(payload.get("players", []), users)]
    for player in live_players:
        player.vs_team = vs_teams.get(player.id)
    active_users.clear()
    registration_start = False
    game_start = True
    return True


def _display_user(user) -> str:
    username = getattr(user, "username", None)
    return f"@{username}" if username else user.full_name


def registration_text() -> str:
    lines = ["🕴 <b>Ro‘yxatdan o‘tish davom etmoqda!</b>", "Ro‘yxatdan o‘tganlar:"]
    if active_users:
        lines.extend(esc(_display_user(user)) for user in active_users)
    else:
        lines.append("Hali hech kim qo‘shilmadi")
    lines.append(f"\nJami: <b>{len(active_users)} ta</b>")
    lines.append("\nO‘yinga qo‘shilish uchun quyidagi tugmani bosing 👇")
    return "\n".join(lines)


def registration_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🟢 Qo‘shilish", callback_data="game_join", style="success")],
    ])


def vs_registration_text() -> str:
    red = [esc(_display_user(user)) for user in active_users if vs_teams.get(user.id) == "red"]
    blue = [esc(_display_user(user)) for user in active_users if vs_teams.get(user.id) == "blue"]
    lines = ["⚔️ <b>VS GAME — jamoa tanlash</b>", "Har bir o‘yinchi 🔴 Qizil yoki 🔵 Ko‘k jamoani tanlaydi.", "", "🔴 <b>Qizil jamoa:</b>"]
    lines.extend(red or ["Hali hech kim yo‘q"])
    lines.append("\n🔵 <b>Ko‘k jamoa:</b>")
    lines.extend(blue or ["Hali hech kim yo‘q"])
    lines.append(f"\nJami: <b>{len(active_users)} ta</b>")
    lines.append("\nJamoaga qo‘shilish uchun tugmalardan birini bosing 👇")
    return "\n".join(lines)


def vs_registration_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔴 Qizil jamoaga qo‘shilish", callback_data="vsgame_join:red", style="danger")],
        [InlineKeyboardButton(text="🔵 Ko‘k jamoaga qo‘shilish", callback_data="vsgame_join:blue", style="primary")],
        [InlineKeyboardButton(text="🚪 O‘yindan chiqish", callback_data="game_leave", style="danger")],
    ])


def game_started_text() -> str:
    lines = ["🎮 <b>O‘yin boshlandi!</b>", "O‘yindan chiqish uchun guruhdagi oddiy Menu’dan <b>/leave</b> buyrug‘ini bosing.", "", "Tirik o‘yinchilar:"]
    if live_players:
        if vs_mode:
            lines.append(", ".join(f"{('🔴' if getattr(player, 'vs_team', None) == 'red' else '🔵')} {esc(player.full_name)}" for player in live_players))
        else:
            lines.append(", ".join(esc(player.full_name) for player in live_players))
    else:
        lines.append("Ro‘yxat bo‘sh")
    lines.append(f"\nJami: <b>{len(live_players)} ta</b>")
    return "\n".join(lines)


def game_started_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[])


async def refresh_registration_message(bot: Bot) -> None:
    if not registration_message_id or not game_chat_id:
        return
    try:
        if game_start:
            text, keyboard = game_started_text(), game_started_keyboard()
        elif vs_mode:
            text, keyboard = vs_registration_text(), vs_registration_keyboard()
        else:
            text, keyboard = registration_text(), registration_keyboard()
        await bot.edit_message_text(
            chat_id=game_chat_id,
            message_id=registration_message_id,
            text=text,
            reply_markup=keyboard,
        )
    except Exception:
        pass


async def add_player_to_registration(user, bot: Bot) -> tuple[bool, str]:
    if not registration_start:
        return False, "O‘yinchilar yig‘ilishi boshlanmagan. Avval /game yozing."
    if any(player.id == user.id for player in active_users):
        return False, "Siz allaqachon ro‘yxatdasiz."
    active_users.append(user)
    _save_game_state("registration")
    await refresh_registration_message(bot)
    return True, "✅ Siz o‘yinga qo‘shildingiz."


async def remove_player_from_registration(user, bot: Bot) -> tuple[bool, str]:
    if not registration_start:
        return False, "Ro‘yxatdan chiqish vaqti tugagan; o‘yin boshlangan."
    if not any(player.id == user.id for player in active_users):
        return False, "Siz ro‘yxatda yo‘qsiz."
    active_users[:] = [player for player in active_users if player.id != user.id]
    vs_teams.pop(user.id, None)
    _save_game_state("registration")
    await refresh_registration_message(bot)
    return True, "🚪 Siz o‘yindan chiqdingiz."


async def remove_player_from_game(user, bot: Bot) -> tuple[bool, str, bool]:
    if not game_start:
        return False, "O‘yin hali boshlanmagan yoki allaqachon tugagan.", False
    from callbacks import game_process
    player = next((item for item in live_players if item.id == user.id), None)
    if player is None:
        return False, "Siz tirik o‘yinchilar ro‘yxatida yo‘qsiz.", False
    live_players.remove(player)
    game_process.night_actions[:] = [action for action in game_process.night_actions if action.user != user.id and action.target != user.id]
    game_process.voted_people[:] = [voter_id for voter_id in game_process.voted_people if voter_id != user.id]
    game_process.accused_people.pop(user.id, None)
    game_process.silenced_people.discard(user.id)
    game_process.    protected_people.discard(user.id)
    _save_game_state("game")
    await refresh_registration_message(bot)

    ended = await game_process._announce_end_or_continue(bot)
    if not ended and not game_process.is_night and len(game_process.voted_people) >= len(live_players) and live_players:
        await game_process.vote_process(bot)
    return True, "🚪 Siz o‘yinni tark etdingiz.", ended


async def role_distribution(bot: Bot):
    """Rollarni aralashtirib, barcha o‘yinchilarga shaxsiy xabarda yuboradi."""
    game_participant_ids.clear()
    game_participant_ids.update(user.id for user in active_users)
    live_players.clear()
    from callbacks.game_process import Mafia, Don, Doctor, Player, Commissioner, Sergeant, Kezuvchi, Daydi, Sorcerer, Advocate, Killer, Wolf
    roles_to_use = list(game_settings.active_roles)
    if len(roles_to_use) < len(active_users):
        roles_to_use.extend(["peaceful man"] * (len(active_users) - len(roles_to_use)))
    roles_to_use = roles_to_use[:len(active_users)]
    random.shuffle(roles_to_use)
    no_dm = []

    factories = {
        "mafia": Mafia,
        "don": Don,
        "doctor": Doctor,
        "peaceful man": Player,
        "kezuvchi": Kezuvchi,
        "sergeant": Sergeant,
        "commissioner": Commissioner,
        "daydi": Daydi,
        "sorcerer": Sorcerer,
        "advocate": Advocate,
        "killer": Killer,
        "wolf": Wolf,
    }
    active_good_roles = ["doctor", "commissioner", "kezuvchi", "sergeant", "daydi", "sorcerer"]
    for user, role in zip(list(active_users), roles_to_use):
        if role == "peaceful man" and _consume_inventory_item(user.id, "faol_rol"):
            role = random.choice(active_good_roles)
        player = factories.get(role, Player)(user)
        player.vs_team = vs_teams.get(user.id)
        live_players.append(player)
        if not await safe_send(bot, user.id, texts.descriptions_dict[role]):
            no_dm.append(user.full_name)
    active_users.clear()
    _save_game_state("game")

    if no_dm:
        await bot.send_message(
            chat_id=game_chat_id,
            text="⚠️ Quyidagi o‘yinchilar rolini shaxsiy xabarda ololmadi: <b>" + esc(", ".join(no_dm)) + "</b>\nBotga shaxsiy chatda /start yozib, o‘yinni qayta boshlang."
        )

    mafias = [player for player in live_players if isinstance(player, Mafia)]
    dons = [player for player in live_players if isinstance(player, Don)]
    if dons:
        don = dons[0]
        family = ", ".join(str(player) for player in mafias) or "hozircha yordamchi yo‘q"
        await safe_send(bot, don.id, f"👑 Siz Don siz.\n🔫 Mafia yordamchilari: <b>{family}</b>\nYakuniy qurbonni faqat siz tanlaysiz.")
        for mafia in mafias:
            await safe_send(bot, mafia.id, f"👑 Sizning Doningiz: <b>{don}</b>\nQurbon bo‘yicha taklifni Donga yuboring.")


async def add_player_to_vs_registration(user, bot: Bot, team: str) -> tuple[bool, str]:
    if not registration_start or not vs_mode:
        return False, "VS Game ro‘yxatdan o‘tishi yopilgan. Avval /vsgame yozing."
    if team not in {"red", "blue"}:
        return False, "Jamoa tanlovi noto‘g‘ri."
    if not any(player.id == user.id for player in active_users):
        active_users.append(user)
    vs_teams[user.id] = team
    _save_game_state("registration")
    await refresh_registration_message(bot)
    label = "🔴 Qizil" if team == "red" else "🔵 Ko‘k"
    return True, f"✅ Siz {label} jamoaga qo‘shildingiz."


async def start_existing_game(bot: Bot, chat_id: int) -> tuple[bool, str]:
    """Mavjud ro‘yxatdagi o‘yinni menyusiz bevosita boshlaydi."""
    global registration_start, game_start
    if not (registration_start or game_start):
        _restore_game_state(chat_id)
    if game_start:
        return False, "🎮 O‘yin allaqachon boshlangan. Yangi o‘yin yaratilmadi."
    if not registration_start or game_chat_id != chat_id:
        return False, "Avval /game yozib yangi o‘yin yarating."
    if len(active_users) < 4:
        return False, "O‘yin uchun kamida 4 o‘yinchi kerak. Yuqoridagi qo‘shilish tugmasini bosing."
    if vs_mode:
        red_count = sum(1 for user in active_users if vs_teams.get(user.id) == "red")
        blue_count = sum(1 for user in active_users if vs_teams.get(user.id) == "blue")
        if not red_count or not blue_count:
            return False, "VS Game boshlanishi uchun Qizil va Ko‘k jamoalarda kamida bittadan o‘yinchi bo‘lishi kerak."

    from callbacks import game_process
    game_settings.save_roles()
    game_process.reset_game_state()
    registration_start = False
    game_start = True
    _save_game_state("game")
    await bot.send_message(chat_id, "🎭 Rollar tarqatilmoqda. Har bir o‘yinchi botning shaxsiy chatini tekshirsin.")
    await role_distribution(bot)
    await refresh_registration_message(bot)
    await bot.send_message(chat_id, "⏱ <b>O‘yin davomiyligi: 2 minut</b>")
    await bot.send_message(chat_id, "🌙 <b>Birinchi tun boshlandi.</b> Tungi harakatlar shaxsiy chatda bajariladi.", reply_markup=kb.go_to_bot_keyboard)
    await game_process.night_phase(live_players, bot)
    return True, "O‘yin boshlandi."


async def open_registration_panel(message: Message, bot: Bot, vs: bool = False):
    global registration_start, game_chat_id, registration_message_id, vs_mode
    if not (registration_start or game_start):
        _restore_game_state(message.chat.id)
    if registration_start or game_start:
        await refresh_registration_message(bot)
        try:
            await message.delete()
        except Exception:
            pass
        return
    reset_registration()
    game_chat_id = message.chat.id
    vs_mode = vs
    registration_start = True
    panel = await message.answer(
        vs_registration_text() if vs else registration_text(),
        reply_markup=vs_registration_keyboard() if vs else registration_keyboard(),
    )
    registration_message_id = panel.message_id
    try:
        await bot.pin_chat_message(chat_id=game_chat_id, message_id=registration_message_id, disable_notification=True)
    except Exception:
        pass
    try:
        await message.delete()
    except Exception:
        pass


@game_registration_router.message(Command("game"), F.chat.type.in_({"group", "supergroup"}))
async def game_registration_cmd(message: Message, bot: Bot):
    # /game oddiy Mafia rejimi uchun ro‘yxatdan o‘tish panelini ochadi.
    await open_registration_panel(message, bot, vs=False)


@game_registration_router.message(Command("vsgame"), F.chat.type.in_({"group", "supergroup"}))
async def vs_game_registration_cmd(message: Message, bot: Bot):
    # Mavjud menyudagi VS Game: jamoalar shu panelning ichida tanlanadi.
    await open_registration_panel(message, bot, vs=True)


@game_registration_router.callback_query(F.data.startswith("vsgame_join:"))
async def vs_game_join_callback(callback: CallbackQuery, bot: Bot):
    if not callback.message:
        await callback.answer("Bu tugma faqat o‘yin guruhida ishlaydi.", show_alert=True)
        return
    if not (registration_start or game_start):
        _restore_game_state(callback.message.chat.id)
    if callback.message.chat.id != game_chat_id:
        await callback.answer("Bu tugma boshqa o‘yin guruhiga tegishli.", show_alert=True)
        return
    team = callback.data.split(":", 1)[1]
    added, response = await add_player_to_vs_registration(callback.from_user, bot, team)
    await callback.answer(response, show_alert=not added)


@game_registration_router.callback_query(F.data == "game_join")
async def game_join_callback(callback: CallbackQuery, bot: Bot):
    if not callback.message:
        await callback.answer("Bu tugma faqat o‘yin guruhida ishlaydi.", show_alert=True)
        return
    if not (registration_start or game_start):
        _restore_game_state(callback.message.chat.id)
    if callback.message.chat.id != game_chat_id:
        await callback.answer("Bu tugma boshqa o‘yin guruhiga tegishli.", show_alert=True)
        return
    if not registration_start:
        await callback.answer("Ro‘yxatdan o‘tish yopilgan.", show_alert=True)
        return
    added, response = await add_player_to_registration(callback.from_user, bot)
    await callback.answer(response, show_alert=not added)


@game_registration_router.callback_query(F.data == "game_leave")
async def game_leave_callback(callback: CallbackQuery, bot: Bot):
    if not callback.message:
        await callback.answer("Bu tugma faqat o‘yin guruhida ishlaydi.", show_alert=True)
        return
    if not (registration_start or game_start):
        _restore_game_state(callback.message.chat.id)
    if callback.message.chat.id != game_chat_id:
        await callback.answer("Bu tugma boshqa o‘yin guruhiga tegishli.", show_alert=True)
        return
    if registration_start:
        removed, response = await remove_player_from_registration(callback.from_user, bot)
        await callback.answer(response, show_alert=not removed)
        return
    if game_start:
        removed, response, ended = await remove_player_from_game(callback.from_user, bot)
        await callback.answer(response, show_alert=not removed)
        if removed and ended:
            try:
                await callback.message.edit_text("🏁 <b>O‘yin yakunlandi.</b>")
            except Exception:
                pass
        return
    await callback.answer("O‘yin allaqachon tugagan.", show_alert=True)


@game_registration_router.message(Command("stop"))
async def stop_game_cmd(message: Message, bot: Bot):
    if message.chat.id != game_chat_id:
        return
    from callbacks import game_process
    had_game = registration_start or game_start
    chat_id = message.chat.id
    try:
        await message.delete()
    except Exception:
        pass
    if game_start:
        await game_process.finish_game()
    elif registration_start:
        reset_registration()
    if had_game:
        await bot.send_message(chat_id, "⏹ <b>Oldingi o‘yin bekor qilindi.</b> Endi /start orqali yangi o‘yin yaratish mumkin.")
    else:
        await bot.send_message(chat_id, "Hozir faol o‘yin yo‘q.")


@game_registration_router.message(Command("leave"))
async def game_leave_cmd(message: Message, bot: Bot):
    if message.chat.id != game_chat_id:
        return
    if registration_start:
        removed, response = await remove_player_from_registration(message.from_user, bot)
        ended = False
    elif game_start:
        removed, response, ended = await remove_player_from_game(message.from_user, bot)
    else:
        removed, response, ended = False, "Hozir faol o‘yin yo‘q.", False
    try:
        await message.delete()
    except Exception:
        pass
    if not removed or ended:
        await bot.send_message(message.chat.id, response if not ended else "🏁 O‘yin chiqish sababli yakunlandi.")


@game_registration_router.message(Command("game"), F.chat.type == "private")
async def game_in_private_cmd(message: Message):
    await message.answer(
        "O‘yin guruhda o‘ynaladi.\n\n"
        "1. Botni guruhga qo‘shing va administrator qiling.\n"
        "2. Har bir o‘yinchi botga shaxsiy chatda /start yozsin.\n"
        "3. Guruhda /game yozing va yashil Qo‘shilish tugmasini bosing.\n"
        "4. Kamida 4 kishi yig‘ilgach /play yozing."
    )


@game_registration_router.message(Command("join"))
async def game_join_cmd(message: Message, bot: Bot):
    if message.chat.id != game_chat_id:
        return
    added, response = await add_player_to_registration(message.from_user, bot)
    try:
        await message.delete()
    except Exception:
        pass
    if not added:
        await bot.send_message(message.chat.id, response)


@game_registration_router.message(Command("play"))
async def game_start_cmd(message: Message, bot: Bot):
    # Eski /play buyrug‘i ham bevosita boshlash oqimiga yo‘naltiriladi.
    try:
        await message.delete()
    except Exception:
        pass
    started, response = await start_existing_game(bot, message.chat.id)
    if not started:
        await bot.send_message(message.chat.id, response)
