import os

from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from callbacks import game_process

from CONFIG import BOT_USERNAME

OWNER_ID = os.getenv("OWNER_ID", "7327126896")
OWNER_USERNAME = os.getenv("OWNER_USERNAME", "JurakhulovE").lstrip("@")


# --- Shaxsiy xabardagi asosiy menyu ---
# Para so‘rash/parani buzish tugmalari yashirilgan; funksiyalar komandalar orqali ishlaydi.
main_menu_keyboard = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="🧑🏻‍💼 Do‘kon", callback_data="menu_shop", style="primary"), InlineKeyboardButton(text="🎁 Kunlik bonus", callback_data="daily:bonus", style="danger")],
    [InlineKeyboardButton(text="🏆 Top o‘yinchilar", callback_data="menu_top_players", style="danger"), InlineKeyboardButton(text="📖 Qoidalar", callback_data="menu_rules", style="primary")],
    [InlineKeyboardButton(text="⭐ PRO sotib olish", callback_data="menu_pro", style="primary"), InlineKeyboardButton(text="🎁 Guruh sovg‘asi", callback_data="promo:2x", style="danger")],
    [InlineKeyboardButton(text="⬛ Mening geroyim", callback_data="menu_my_hero", style="danger")],
])

owner_admin_keyboard = InlineKeyboardMarkup(inline_keyboard=[
    *main_menu_keyboard.inline_keyboard,
    [InlineKeyboardButton(text="🔐 Yashirin Owner sozlamalari", callback_data="owner:menu", style="primary")],
    [InlineKeyboardButton(text="🔐 Admin panel", callback_data="admin:panel", style="danger")],
])

owner_menu_keyboard = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="🔐 Admin panel", callback_data="admin:panel", style="danger")],
    [InlineKeyboardButton(text="⬅️ Asosiy menyu", callback_data="menu_back", style="primary")],
])

back_keyboard = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text = "⬅️ Orqaga", callback_data = "menu_back")],
])

# Profil oynasida ham faqat asosiy bo‘limlar qoladi.
profile_menu_keyboard = main_menu_keyboard

# /start bosilganda faqat o‘yin guruhlari, guruhga qo‘shish va kabinet chiqadi.
start_keyboard = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="💼 Shaxsiy kabinet", callback_data="menu_account", style="danger")],
    [InlineKeyboardButton(text="🎮 O‘yin guruhlari", callback_data="menu_game_create", style="primary"), InlineKeyboardButton(text="👑 Owner menyusi", url=f"https://t.me/{OWNER_USERNAME}", style="primary")],
    [InlineKeyboardButton(text="➕ Botni guruhga qo‘shish", url=f"https://t.me/{BOT_USERNAME}?startgroup=true", style="success")],
])

go_to_bot_keyboard = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text = "🌙 Botga o'tish", url = f"https://t.me/{BOT_USERNAME}")],
])

add_bot_to_group_keyboard = main_menu_keyboard


# --- O'yin sozlamalari ---

manual_settings_buttons = [
            [InlineKeyboardButton(text="🔫 Mafiya qo'shish", callback_data='edit_mafia')],
            [InlineKeyboardButton(text="🩺 Doctor qo\'shish", callback_data='edit_doctor')],
            [InlineKeyboardButton(text='🕵️‍♂️ Komissar katani qo\'shish', callback_data='edit_sheriff')],
            [InlineKeyboardButton(text='✅ Saqlash', callback_data='save_settings')]
            ]
manual_role_settings_keyboard = InlineKeyboardMarkup(inline_keyboard=manual_settings_buttons)


select_settings_buttons=[[InlineKeyboardButton(text='▶️ O\'yinni boshlash', callback_data='start_game')]]
select_settings_keyboard = InlineKeyboardMarkup(inline_keyboard = select_settings_buttons)

edit_mafia_buttons = [
    [InlineKeyboardButton(text='➕',callback_data='plus_mafia'),InlineKeyboardButton(text='➖',callback_data='minus_mafia')],
    [InlineKeyboardButton(text='⬅️ Orqaga',callback_data='go_back')]]
edit_mafia_keyboard = InlineKeyboardMarkup(inline_keyboard=edit_mafia_buttons)

edit_doctor_buttons = [
    [InlineKeyboardButton(text='➕',callback_data='plus_doctor'),InlineKeyboardButton(text='➖',callback_data='minus_doctor')],
    [InlineKeyboardButton(text='⬅️ Orqaga',callback_data='go_back')]]
edit_doctor_keyboard = InlineKeyboardMarkup(inline_keyboard=edit_doctor_buttons)

edit_sheriff_buttons = [
    [InlineKeyboardButton(text='➕',callback_data='plus_sheriff'),InlineKeyboardButton(text='➖',callback_data='minus_sheriff')],
    [InlineKeyboardButton(text='⬅️ Orqaga',callback_data='go_back')]]
edit_sheriff_keyboard = InlineKeyboardMarkup(inline_keyboard=edit_sheriff_buttons)
