import asyncio
import logging
import os

from aiogram.exceptions import TelegramAPIError
from aiogram.client.session.aiohttp import AiohttpSession
import aiohttp
from aiohttp import web

from CONFIG import TOKEN

# Метка сборки: видна на health-эндпоинте, по ней снаружи понятно,
# какая версия реально задеплоена
BUILD = "uz-menu-2-keepalive"

# Через сколько секунд повторять самопинг. Render усыпляет сервис
# после 15 минут без входящих запросов, поэтому берём с запасом.
KEEP_ALIVE_INTERVAL = int(os.getenv("KEEP_ALIVE_INTERVAL", "600"))

# На бесплатном PythonAnywhere весь исходящий трафик идёт только через их прокси.
# api.telegram.org в белом списке, но aiohttp сам прокси не подхватывает — задаём явно.
PROXY = os.getenv("TG_PROXY") or (
    "http://proxy.server:3128" if os.getenv("PYTHONANYWHERE_DOMAIN") else None
)


import texts

from aiogram import Dispatcher, Bot, BaseMiddleware
from aiogram.client.bot import DefaultBotProperties

from aiogram import F
from aiogram.types import Message, CallbackQuery, BotCommand, BotCommandScopeAllPrivateChats, BotCommandScopeAllGroupChats
from aiogram.filters import Command, CommandStart, BaseFilter

from aiogram.types.chat_permissions import ChatPermissions

from handlers import registration, economy

from callbacks.game_process import apscheduler

import keyboards as kb

from callbacks import game_settings, game_process

dp = Dispatcher()


class DeleteGroupCommandMiddleware(BaseMiddleware):
    async def __call__(self, handler, event, data):
        if isinstance(event, Message) and event.from_user:
            try:
                economy.ensure_profile(event.from_user)
                economy.remember_group_chat(event.chat)
            except Exception:
                logging.exception("Foydalanuvchi profilini saqlashda xato")
        result = await handler(event, data)
        if isinstance(event, Message) and event.chat.type in {"group", "supergroup"}:
            text = event.text or ""
            if text.startswith("/"):
                try:
                    await event.delete()
                except TelegramAPIError:
                    pass
        return result


dp.message.middleware(DeleteGroupCommandMiddleware())


@dp.message(CommandStart(), F.chat.type.in_({"group", "supergroup"}))
async def group_start_command(message: Message, bot: Bot):
    # Guruhda /start mavjud /game ro‘yxatini menyusiz bevosita boshlaydi.
    started, response = await registration.start_existing_game(bot, message.chat.id)
    if not started:
        await bot.send_message(message.chat.id, response)


@dp.message(CommandStart(), F.chat.type == "private")
async def start_command(message: Message):
    economy.ensure_profile(message.from_user)
    await message.answer(texts.start_text, reply_markup=kb.start_keyboard)


@dp.message(Command("help"))
async def help_command(message: Message):
    await message.answer(texts.help_text, reply_markup=kb.back_keyboard)


@dp.message(Command("rules"))
async def rules_command(message: Message):
    await message.answer(texts.rules_text, reply_markup=kb.back_keyboard)


@dp.message(Command("roles"))
async def roles_command(message: Message):
    await message.answer(texts.roles_text, reply_markup=kb.back_keyboard)


# --- Menyu tugmalari: xabarni almashtirib "oyna" effektini beradi ---

MENU_PAGES = {
    "menu_rules": texts.rules_text,
    "menu_roles": texts.roles_text,
    "menu_help": texts.help_text,
    "menu_back": texts.start_text,
}


@dp.callback_query(F.data == "menu_shop")
async def menu_shop_callback(callback: CallbackQuery):
    await callback.message.edit_text("🧑🏻‍💼 <b>Do‘kon</b>\n\nKerakli bo‘limni tanlang:", reply_markup=economy.shop_keyboard())
    await callback.answer()


@dp.callback_query(F.data == "menu_my_hero")
async def menu_my_hero_callback(callback: CallbackQuery):
    hero = economy.ensure_hero(callback.from_user)
    if not hero["owned"]:
        text = "🕶 <b>Mening geroyim</b>\n\n❌ Sizda hozircha geroy yo‘q.\n\nGeroy sotib olingandan keyin uni kuchaytirish va o‘yin vaqtida ishlatish mumkin.\n\nNarxi: <b>200 💎</b>"
        await callback.message.edit_text(text, reply_markup=economy.hero_buy_keyboard())
    else:
        await callback.message.edit_text(economy.hero_text(hero), reply_markup=economy.hero_keyboard())
    await callback.answer()


@dp.callback_query(F.data == "menu_profile")
async def menu_profile_callback(callback: CallbackQuery):
    profile = economy.ensure_profile(callback.from_user)
    menu = kb.owner_admin_keyboard if callback.from_user.id == economy.OWNER_ID else kb.profile_menu_keyboard
    await callback.message.edit_text(economy.profile_text(profile), reply_markup=menu)
    await callback.answer()


@dp.callback_query(F.data == "menu_account")
async def menu_account_callback(callback: CallbackQuery):
    profile = economy.ensure_profile(callback.from_user)
    menu = kb.owner_admin_keyboard if callback.from_user.id == economy.OWNER_ID else kb.profile_menu_keyboard
    await callback.message.edit_text(economy.profile_text(profile), reply_markup=menu)
    await callback.answer()


@dp.callback_query(F.data == "owner:menu")
async def owner_menu_callback(callback: CallbackQuery):
    if callback.from_user.id != economy.OWNER_ID:
        await callback.answer("Bu menyu faqat bot egasiga tegishli.", show_alert=True)
        return
    profile = economy.ensure_profile(callback.from_user)
    username = f"@{callback.from_user.username}" if callback.from_user.username else "username yo‘q"
    await callback.message.edit_text(
        "👑 <b>OWNER MENYUSI</b>\n\n"
        f"👤 Joriy username: <b>{username}</b>\n"
        "Username o‘zgartirilsa, bu menyuni qayta ochganda yangi username ko‘rinadi.\n\n"
        + economy.profile_text(profile),
        reply_markup=kb.owner_menu_keyboard,
    )
    await callback.answer()


@dp.callback_query(F.data == "menu_game_create")
async def menu_game_create_callback(callback: CallbackQuery):
    await callback.message.edit_text(economy.game_groups_text(), reply_markup=economy.game_groups_keyboard())
    await callback.answer()


@dp.callback_query(F.data.startswith("game_group:invite:"))
async def game_group_invite_callback(callback: CallbackQuery, bot: Bot):
    chat_id = int(callback.data.rsplit(":", 1)[1])
    with economy._connect() as connection:
        group = connection.execute("SELECT title FROM game_groups WHERE chat_id=?", (chat_id,)).fetchone()
    if group is None:
        await callback.answer("Guruh topilmadi.", show_alert=True)
        return
    try:
        invite = await bot.create_chat_invite_link(chat_id=chat_id, name="Mafia bot arizasi", creates_join_request=True)
    except Exception:
        await callback.answer("Bu yopiq guruh uchun ariza havolasini yaratib bo‘lmadi. Bot admin ekanini tekshiring.", show_alert=True)
        return
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📩 Guruhga kirish uchun ariza yuborish", url=invite.invite_link, style="success")],
        [InlineKeyboardButton(text="⬅️ Guruhlar ro‘yxati", callback_data="menu_game_create", style="primary")],
    ])
    await callback.message.edit_text(
        f"🎮 <b>{economy.esc(group['title'])}</b>\n\nAriza yuborish uchun quyidagi tugmani bosing:",
        reply_markup=keyboard,
    )
    await callback.answer()


@dp.callback_query(F.data == "menu_economy")
async def menu_economy_callback(callback: CallbackQuery):
    await callback.message.edit_text("💎 <b>Iqtisod buyruqlari</b>\n\n/profil — balans va status\n/shop — do‘kon\n/inventar — inventar\n/sandiq — sandiq\n/almash — almazni coin qilish\n/kurs — valyuta kursi", reply_markup=kb.back_keyboard)
    await callback.answer()


@dp.callback_query(F.data == "menu_pair")
async def menu_pair_callback(callback: CallbackQuery):
    await callback.message.edit_text("💞 <b>Para so‘rash</b>\n\nGuruhda biror odamning xabariga reply qilib /para yozing. U qabul qilsa, haqiqiy juftlik bo‘lasiz.", reply_markup=kb.back_keyboard)
    await callback.answer()


@dp.callback_query(F.data == "menu_dpara")
async def menu_dpara_callback(callback: CallbackQuery):
    await callback.message.edit_text("💔 <b>Parani buzish</b>\n\nJuftlikni buzish uchun guruhda oddiy /dpara yozing.", reply_markup=kb.back_keyboard)
    await callback.answer()


@dp.callback_query(F.data == "menu_vip")
async def menu_vip_callback(callback: CallbackQuery):
    profile = economy.ensure_profile(callback.from_user)
    await callback.message.edit_text(economy.profile_text(profile) + "\n\n👑 VIP statusini tekshirish yoki VIP User sotib olish uchun /vip yoki Do‘kon bo‘limidan foydalaning.", reply_markup=kb.back_keyboard)
    await callback.answer()


@dp.callback_query(F.data == "menu_top")
async def menu_top_callback(callback: CallbackQuery):
    await callback.message.edit_text("🏆 <b>Ballar reytingi</b>\n\nGuruhda ishlating:\n/top — umumiy\n/top 1 — oxirgi 1 kun\n/top 7 — oxirgi 7 kun\n/top 30 — oxirgi 30 kun.", reply_markup=kb.back_keyboard)
    await callback.answer()


@dp.callback_query(F.data == "menu_gift")
async def menu_gift_callback(callback: CallbackQuery):
    await callback.message.edit_text("🎁 <b>Gift yuborish</b>\n\nFoydalanish: /gift @username coin_miqdori", reply_markup=kb.back_keyboard)
    await callback.answer()


@dp.callback_query(F.data == "menu_inventory")
async def menu_inventory_callback(callback: CallbackQuery):
    await callback.message.edit_text("🎒 <b>Inventar</b>\n\nInventaringizni ko‘rish uchun /inventar buyrug‘ini yuboring.", reply_markup=kb.back_keyboard)
    await callback.answer()


@dp.callback_query(F.data == "menu_chest")
async def menu_chest_callback(callback: CallbackQuery):
    await economy.chest_menu(callback)


@dp.callback_query(F.data == "menu_exchange")
async def menu_exchange_callback(callback: CallbackQuery):
    await economy.exchange_menu(callback)


@dp.callback_query(F.data == "menu_pro")
async def menu_pro_callback(callback: CallbackQuery):
    await economy.show_pro_menu(callback)
    await callback.answer()


@dp.callback_query(F.data == "menu_hero")
async def menu_hero_callback(callback: CallbackQuery):
    hero = economy.ensure_hero(callback.from_user)
    if not hero["owned"]:
        await callback.message.edit_text("🕶 <b>Geroy</b>\n\nGeroy sotib olingandan keyin daraja, kuch, himoya va hujum imkoniyatlari ochiladi.\n\nNarxi: <b>90 💎</b>", reply_markup=economy.hero_buy_keyboard())
    else:
        await callback.message.edit_text(economy.hero_text(hero), reply_markup=economy.hero_keyboard())
    await callback.answer()


@dp.callback_query(F.data == "menu_mypara")
async def menu_mypara_callback(callback: CallbackQuery):
    await callback.message.edit_text("💞 <b>Mening para</b>\n\nHaqiqiy juftlikni ko‘rish uchun /mypara buyrug‘ini yuboring.", reply_markup=kb.back_keyboard)
    await callback.answer()


@dp.callback_query(F.data.in_(MENU_PAGES.keys()))
async def menu_navigation(callback: CallbackQuery):
    if callback.data == "menu_back":
        profile = economy.ensure_profile(callback.from_user)
        text = economy.profile_text(profile)
        markup = kb.owner_admin_keyboard if callback.from_user.id == economy.OWNER_ID else kb.profile_menu_keyboard
    else:
        text = MENU_PAGES[callback.data]
        markup = kb.back_keyboard
    try:
        await callback.message.edit_text(text, reply_markup=markup)
    except TelegramAPIError:
        await callback.message.answer(text, reply_markup=markup)
    await callback.answer()


async def set_commands(bot: Bot):
    """Telegramdagi 'Menu' tugmasida buyruqlar ro'yxati chiqib turadi."""
    await bot.set_my_commands(
        [
            BotCommand(command = "start", description = "🔵 Asosiy ma’lumot"),
            BotCommand(command = "profil", description = "🧔 Profil va katta menyu"),
            BotCommand(command = "topplayers", description = "💰 Top o‘yinchilar"),
            BotCommand(command = "rules", description = "📜 O‘yin qoidalari"),
            BotCommand(command = "roles", description = "♠️ Rollar"),
            BotCommand(command = "help", description = "⚙️ Buyruqlar"),
        ],
        scope = BotCommandScopeAllPrivateChats(),
    )
    # Guruh menyusida faqat klassik Mafia o‘yini va para buyruqlari qoladi.
    # VS, sotqin, nik, zombie va boshqa rejimlar menyudan olib tashlanadi.
    await bot.set_my_commands(
        [
            BotCommand(command="game", description="🎭 Klassik Mafia o‘yini"),
            BotCommand(command="join", description="✅ O‘yinga qo‘shilish"),
            BotCommand(command="play", description="▶️ O‘yinni boshlash"),
            BotCommand(command="leave", description="🚪 O‘yindan chiqish"),
            BotCommand(command="stop", description="⏹ O‘yinni to‘xtatish"),
            BotCommand(command="para", description="💞 Para qilish"),
            BotCommand(command="dpara", description="💔 Parani buzish"),
            BotCommand(command="mypara", description="💞 Mening para"),
            BotCommand(command="top", description="🏆 Ballar reytingi"),
            BotCommand(command="help", description="ℹ️ Yordam"),
        ],
        scope=BotCommandScopeAllGroupChats(),
    )


async def on_shutdown(bot: Bot):
    # игры может не быть — тогда возвращать права некому
    if not registration.game_chat_id:
        return
    try:
        await bot.set_chat_permissions(chat_id = registration.game_chat_id, permissions = ChatPermissions(can_send_messages = True), use_independent_chat_permissions = False)
    except TelegramAPIError as e:
        logging.warning("Не удалось вернуть права чату: %s", e)

async def on_sturtup(bot: Bot):
    me = await bot.get_me()
    # регистрация команд не должна мешать боту стартовать
    try:
        await set_commands(bot)
        logging.info("Команды зарегистрированы")
    except TelegramAPIError as e:
        logging.warning("Не удалось зарегистрировать команды: %s", e)
    logging.info("Бот @%s запущен, сборка %s", me.username, BUILD)

async def health_server():
    """Render Free даёт только Web Service — процесс обязан слушать $PORT,
    иначе деплой падает с 'no open ports detected'.
    Этот же адрес дёргает внешний пингер, чтобы сервис не засыпал через 15 минут.
    """
    port = int(os.getenv("PORT", "0"))
    if not port:
        return
    app = web.Application()
    app.router.add_get("/", lambda r: web.Response(text = f"mafia bot is alive | build {BUILD}"))
    runner = web.AppRunner(app)
    await runner.setup()
    await web.TCPSite(runner, "0.0.0.0", port).start()
    logging.info("Health-сервер слушает порт %s", port)


async def keep_alive():
    """Бесплатный Render усыпляет сервис после 15 минут без входящих запросов,
    а во сне умирают игровые таймеры (ночь, обсуждение) — партия зависает.

    Раз в 10 минут дёргаем собственный публичный адрес: запрос уходит наружу
    и возвращается через Render как входящий, поэтому счётчик простоя сбрасывается.
    Адрес Render сам кладёт в RENDER_EXTERNAL_URL, вручную ничего указывать не нужно.
    """
    url = os.getenv("KEEP_ALIVE_URL") or os.getenv("RENDER_EXTERNAL_URL")
    if not url:
        logging.info("Самопинг выключен: адрес сервиса неизвестен")
        return
    logging.info("Самопинг включён: %s каждые %s с", url, KEEP_ALIVE_INTERVAL)
    await asyncio.sleep(KEEP_ALIVE_INTERVAL)
    async with aiohttp.ClientSession() as session:
        while True:
            try:
                async with session.get(url, timeout = aiohttp.ClientTimeout(total = 30)) as resp:
                    logging.info("Самопинг: %s", resp.status)
            except Exception as e:
                logging.warning("Самопинг не прошёл: %s", e)
            await asyncio.sleep(KEEP_ALIVE_INTERVAL)


async def start():
    logging.basicConfig(level = logging.INFO)
    await health_server()
    asyncio.create_task(keep_alive())
    apscheduler.start()
    dp.include_routers(economy.economy_router, registration.game_registration_router, game_settings.game_settings_router, game_process.night_router, game_process.day_router)
    if PROXY:
        logging.info("Использую прокси: %s", PROXY)
        bot = Bot(token = TOKEN, session = AiohttpSession(proxy = PROXY), default = DefaultBotProperties(parse_mode = 'HTML'))
    else:
        bot = Bot(token = TOKEN, default = DefaultBotProperties(parse_mode = 'HTML'))
    dp.shutdown.register(on_shutdown)
    dp.startup.register(on_sturtup)
    await bot.delete_webhook(drop_pending_updates = True)
    await dp.start_polling(bot)
    
if __name__ == '__main__':
    asyncio.run(start())
