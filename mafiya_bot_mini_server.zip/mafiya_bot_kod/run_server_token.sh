#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"
export BOT_TOKEN='8654610722:AAHmG9pxgh_SdphVxfmCgurrnVRfW_0P5vU'
export OWNER_ID='7327126896'
export BOT_USERNAME='Dkkfkfdkdk_bot'
export ECONOMY_DB="${ECONOMY_DB:-$PWD/data/economy.sqlite3}"
export GAME_STATE_FILE="${GAME_STATE_FILE:-$PWD/data/mafia_game_state.json}"
mkdir -p "$(dirname "$ECONOMY_DB")" "$(dirname "$GAME_STATE_FILE")"
exec python3 run.py
