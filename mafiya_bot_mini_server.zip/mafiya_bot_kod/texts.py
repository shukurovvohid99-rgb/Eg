try:
    from CONFIG import BOT_TITLE
except ImportError:
    BOT_TITLE = "Mafia Bot"


start_text = """Salom!

Men mafiya botiman. Do‘stlar bilan mafiya o‘ynash uchun meni guruhingizga qo‘shing.

Meni guruhga admin qilib qo‘yganingizdan so‘ng, o‘yinni boshlashingiz mumkin."""

rules_text = """📜 <b>MAFIA O‘YINI QOIDALARI</b>

<b>🎯 Maqsad</b>
O‘yinda ikki asosiy jamoa mavjud:
• <b>Tinch aholi</b> — barcha Mafiyani topib, ovoz berish orqali chiqarib yuborishi kerak.
• <b>Mafiya</b> — o‘z sonini Tinch aholi soniga teng yoki undan ko‘p holatga keltirishi kerak.

━━━━━━━━━━━━━━

<b>🎭 ROLLAR</b>

<b>👨🏼 Tinch aholi</b>
• Maxsus qobiliyati yo‘q.
• Muhokama qiladi va ovoz beradi.
• Oxirigacha tirik qolishga harakat qiladi.

<b>🤵🏼 Mafiya</b>
• Kechasi Don bilan birga bitta odamni o‘ldirishga ovoz beradi.
• Kunduzi o‘zini Tinch aholi qilib ko‘rsatadi.
• Boshqa Mafia a’zolarini va Donni biladi.

<b>🤵🏻 Don</b>
• Mafia rahbari.
• Tunda kim o‘ldirilishini yakuniy hal qiladi, ovozlar teng bo‘lsa qaror beradi.
• Don o‘lsa, tirik Mafialardan biri avtomatik yangi Don bo‘ladi.

<b>🕵🏻‍♂ Komissar</b>
• Har kecha bitta o‘yinchini tekshiradi yoki birini otadi.
• Tekshiruv natijasi faqat o‘ziga ko‘rinadi va aniq rol ko‘rsatiladi.

<b>👨🏻‍⚕ Doktor</b>
• Har kecha bitta odamni davolaydi.
• Agar Mafia yoki Komissar aynan shu odamni nishonga olgan bo‘lsa, u tirik qoladi.

<b>💃 Kezuvchi</b>
• Har kecha bitta odamning oldiga borib, uni uxlatadi.
• Uxlagan o‘yinchi o‘sha tunda hech qanday harakat qila olmaydi.

<b>👮🏻‍♂ Serjant</b>
• Maxsus qobiliyati yo‘q, Tinch aholi kabi kutadi.
• Komissar o‘lsa, uning o‘rniga avtomatik yangi Komissar bo‘ladi.

━━━━━━━━━━━━━━

<b>🕹 O‘YIN BOSQICHLARI</b>

<b>1️⃣ O‘yin boshlanishi</b>
Bot rollarni tasodifiy taqsimlaydi. Har kim faqat o‘z rolini ko‘radi. Mafialar bir-birini biladi.

<b>2️⃣ Kecha</b>
Navbat bilan: Don/Mafia → Komissar → Doktor → Kezuvchi. Har biri faqat o‘z navbatida harakat qiladi.

<b>3️⃣ Tong</b>
Bot kim o‘lganini e’lon qiladi. Kim saqlab qolingani odatda oshkor qilinmaydi.

<b>4️⃣ Muhokama</b>
Barcha tirik o‘yinchilar gaplashadi, gumon qiladi va dalillar keltiradi.

<b>5️⃣ Ovoz berish</b>
Hamma bitta odamga ovoz beradi. Eng ko‘p ovoz olgan o‘yinchi tasdiqlash ovozidan keyin chiqariladi va uning roli ochiladi.

<b>6️⃣ Keyingi kecha</b>
Yuqoridagi bosqichlar g‘alaba shartlaridan biri bajarilguncha takrorlanadi.

━━━━━━━━━━━━━━

<b>🏆 G‘ALABA SHARTLARI</b>

<b>Tinch aholi g‘alabasi</b> — barcha Mafia, ya’ni Don va Mafia chiqarib yuborilsa.

<b>Mafia g‘alabasi</b> — Mafia soni qolgan Tinch aholi soniga teng yoki undan ko‘p bo‘lsa.
Misollar: 2 Mafia + 2 fuqaro; 1 Mafia + 1 fuqaro; 3 Mafia + 2 fuqaro.

━━━━━━━━━━━━━━

<b>🗳 OVOZ BERISH QOIDALARI</b>
• Har o‘yinchi faqat bitta ovoz beradi.
• O‘ziga ovoz berish mumkin emas.
• Ovozni vaqt tugashidan oldin o‘zgartirish mumkin.
• Teng ovoz bo‘lsa, hech kim chiqarilmaydi.

<b>👨🏻‍⚕ Doktor qoidasi</b>
Ketma-ket bir odamni davolash cheklanishi mumkin.

<b>🕵🏻‍♂ Komissar qoidasi</b>
Tekshiruv natijasi “Mafia” yoki “Mafia emas” emas — aniq rol ko‘rsatiladi. Natija faqat Komissarning o‘ziga ko‘rinadi."""

roles_text = """📜 <b>MAFIA ROLLARI VA VAZIFALARI</b>

<b>👨🏼 TINCH AHOLI TOMONI</b>

👨🏼 <b>Tinch aholi</b> — maxsus qobiliyati yo‘q. Muhokama qiladi, ovoz beradi va Mafia tomonini topishga harakat qiladi.

💃 <b>Kezuvchi</b> — har kecha bitta o‘yinchining oldiga borib, uni uxlatadi. Uxlagan o‘yinchi o‘sha tunda harakat qila olmaydi. Komissarni uxlatmasligi kerak.

👮🏻‍♂ <b>Serjant</b> — Komissarga yordam beradi. Komissar vafot etsa, uning o‘rniga avtomatik yangi Komissar bo‘ladi.

🕵🏻‍♂ <b>Komissar katani</b> — shaharning asosiy himoyachisi. Har kecha bir o‘yinchini tekshiradi yoki, birinchi tundan keyin, otishi mumkin. Birinchi tunda tekshirmasdan otish taqiqlanadi. Tekshiruv natijasi faqat Komissarga ko‘rinadi va aniq rol ko‘rsatiladi.

👨🏻‍⚕ <b>Doktor</b> — har kecha bir o‘yinchini davolaydi. Mafia yoki Komissar nishonga olgan odam davolangan bo‘lsa, tirik qoladi. O‘zini faqat bir marta davolashi mumkin.

🧙‍♂️ <b>Daydi</b> — tunda bir o‘yinchining oldiga boradi va u yerda qotillik bo‘lsa, qotilni ko‘rishi mumkin.

🧞‍♂️ <b>Afsungar</b> — tunda uni o‘ldirgan o‘yinchini o‘zi bilan olib ketadi. Kunduzgi ovozda chiqarilsa, o‘zi bilan bitta o‘yinchini olib ketishni tanlaydi.

<b>🤵🏼 MAFIYA TOMONI</b>

🤵🏻 <b>Don</b> — Mafia rahbari. Tunda yakuniy qurbonni tanlaydi. Don o‘lsa, tirik Mafialardan biri avtomatik yangi Don bo‘ladi.

🤵🏼 <b>Mafia</b> — Don bilan birga tungi qurbonni tanlaydi, Donga taklif yuboradi va kunduzi o‘zini Tinch aholi qilib ko‘rsatadi.

👨‍💼 <b>Advokat</b> — tunda himoya qilinadigan o‘yinchini tanlaydi. Agar Mafia a’zosini himoya qilsa, Komissar uni Tinch aholi deb ko‘radi. Mafia g‘alabasiga yordam beradi.

<b>🔪 MUSTAQIL TOMON</b>

🔪 <b>Qotil</b> — tunda o‘yinchilarni o‘ldiradi. Faqat o‘zi tirik qolsa g‘alaba qiladi.

🐺 <b>Bo‘ri</b> — kim o‘ldirganiga qarab o‘zgaradi: Mafia o‘ldirsa keyingi kecha Mafia bo‘ladi, Komissar otsa Serjantga aylanadi, Qotil o‘ldirsa vafot etadi.

<b>🕹 O‘YIN TARTIBI</b>
O‘yin boshlanganda rollar tasodifiy tarqatiladi va har kim faqat o‘z rolini ko‘radi. Tunda maxsus rollar botning shaxsiy chatida navbat bilan harakat qiladi. Tongda natija guruhda e’lon qilinadi, tiriklar muhokama qiladi va ovoz beradi. Teng ovoz bo‘lsa, hech kim chiqarilmaydi. Barcha Mafia chiqarilsa Tinch aholi, Mafia soni qolgan Tinch aholi soniga teng yoki undan ko‘p bo‘lsa Mafia g‘alaba qiladi."""

help_text = """ℹ️ <b>Buyruqlar</b>

<b>Guruhda:</b>
/game — yangi o‘yin yaratish va ro‘yxatdan o‘tishni ochish
/join — o‘yinga qo‘shilish
/start — mavjud ro‘yxatdagi o‘yinni bevosita boshlash
/leave — o‘yindan chiqish
/stop — faol o‘yinni bekor qilish

<b>Shaxsiy chatda:</b>
/start — botni ishga tushirish
/profil — katta menyu
/rules — o‘yin qoidalari
/roles — rollar va vazifalar

<b>Muhim:</b>
Bot guruhda administrator bo‘lsin, har bir o‘yinchi botga shaxsiy chatda /start yozsin, guruhda /game orqali ro‘yxatdan o‘tsin va kamida 4 o‘yinchi yig‘ilgach /start yuborilsin."""


don_description = "Siz 🤵🏻 <b>Don</b>siz. Mafia takliflarini olasiz va yakuniy qurbonni o‘zingiz tanlaysiz."
mafia_description = "Siz 🤵🏼 <b>Mafia</b>siz. Tunda Donga bitta qurbonni taklif qilasiz."
citizen_description = "Siz 👨🏼 <b>Tinch aholi</b>siz. Kunduz muhokama va ovoz orqali Mafia tomonini toping."
doctor_description = "Siz 👨🏻‍⚕ <b>Doctor</b>siz. Tunda bir o‘yinchini davolaysiz; o‘zingizni faqat bir marta davolay olasiz."
kezuvchi_description = "Siz 💃 <b>Kezuvchi</b>siz. Tunda bir o‘yinchini uxlatib, keyingi kunduz ovozdan mahrum qilasiz. Komissarni uxlatmang."
sergeant_description = "Siz 👮🏻‍♂ <b>Serjant</b>siz. Komissar vafot etsa, uning o‘rnini egallaysiz."
commissioner_description = "Siz 🕵🏻‍♂ <b>Komissar katani</b>siz. Tunda tekshiring; birinchi tunda tekshirmasdan otish taqiqlanadi."
daydi_description = "Siz 🧙‍♂️ <b>Daydi</b>siz. Tunda bir o‘yinchining oldiga borib, qotillikka guvoh bo‘lishga harakat qilasiz."
sorcerer_description = "Siz 🧞‍♂️ <b>Afsungar</b>siz. Sizni o‘ldirgan qotilni o‘zingiz bilan olib ketasiz; kunduz chiqarilsangiz, bir o‘yinchini tanlab olib keting."
advocate_description = "Siz 👨‍💼 <b>Advokat</b>siz. Tunda Mafia a’zosini himoya qilsangiz, Komissar uni Tinch aholi deb ko‘radi."
killer_description = "Siz 🔪 <b>Qotil</b>siz. Tunda o‘ldiring; faqat o‘zingiz tirik qolsangiz g‘alaba qilasiz."
wolf_description = "Siz 🐺 <b>Bo‘ri</b>siz. Mafia otsa Mafia bo‘lib, Komissar otsa Serjant bo‘lib tirilasiz; Qotil o‘ldirsa o‘lasiz."


descriptions_dict = {
    "don": don_description,
    "mafia": mafia_description,
    "peaceful man": citizen_description,
    "doctor": doctor_description,
    "kezuvchi": kezuvchi_description,
    "sergeant": sergeant_description,
    "commissioner": commissioner_description,
    "daydi": daydi_description,
    "sorcerer": sorcerer_description,
    "advocate": advocate_description,
    "killer": killer_description,
    "wolf": wolf_description,
}
