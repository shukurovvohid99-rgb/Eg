import html
import logging

from aiogram import Bot
from aiogram.exceptions import TelegramAPIError

log = logging.getLogger(__name__)


def esc(text) -> str:
    """Экранирует HTML, иначе ник со знаком < или & ломает отправку сообщения."""
    return html.escape(str(text), quote=False)


async def safe_set_permissions(bot: Bot, chat_id: int, can_send: bool, **kwargs) -> bool:
    """Закрыть/открыть чат. Если бота не сделали админом, Telegram вернёт ошибку —
    без этой обёртки она обрывала всю партию.
    """
    from aiogram.types.chat_permissions import ChatPermissions
    try:
        await bot.set_chat_permissions(
            chat_id = chat_id,
            permissions = ChatPermissions(can_send_messages = can_send),
            **kwargs,
        )
        return True
    except TelegramAPIError as e:
        log.warning("Не удалось изменить права чата %s (бот не админ?): %s", chat_id, e)
        return False


async def safe_send(bot: Bot, chat_id: int, text: str, **kwargs) -> bool:
    """Отправка, которая не роняет игру.

    Если игрок не писал боту в личку или заблокировал его, Telegram отвечает 403
    (TelegramForbiddenError). Без этой обёртки одно такое исключение убивает всю партию.
    Возвращает True, если сообщение доставлено.
    """
    try:
        await bot.send_message(chat_id=chat_id, text=text, **kwargs)
        return True
    except TelegramAPIError as e:
        log.warning("Не удалось отправить сообщение %s: %s", chat_id, e)
        return False
